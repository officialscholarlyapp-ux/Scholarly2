import { Redirect } from 'expo-router';
import { useAuth } from '@/lib/auth-context';
import { View, ActivityIndicator } from 'react-native';
import { Colors } from '@/constants/theme';

export default function Index() {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.dark.background }}><ActivityIndicator color={Colors.primary} size="large" /></View>;
  return <Redirect href={isAuthenticated ? '/(app)/(tabs)' : '/(auth)/splash'} />;
}
