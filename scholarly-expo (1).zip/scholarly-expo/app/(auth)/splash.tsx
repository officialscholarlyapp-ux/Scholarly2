import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { useAuth } from '@/lib/auth-context';
import { Colors } from '@/constants/theme';

const { height } = Dimensions.get('window');
const features = [{ emoji: '📊', label: 'GPA Tracker' }, { emoji: '📚', label: 'Homework Planner' }, { emoji: '🧠', label: 'AI Study Tools' }, { emoji: '🎯', label: 'Get an A' }];
type Mode = 'landing' | 'signin' | 'signup';

export default function SplashScreen() {
  const { signInWithEmail, signUpWithEmail, signInWithGoogle, signInWithApple } = useAuth();
  const [mode, setMode] = useState<Mode>('landing');
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [name, setName] = useState('');
  const [showPw, setShowPw] = useState(false); const [loading, setLoading] = useState(false); const [error, setError] = useState<string | null>(null);

  const handleAuth = async () => {
    if (!email || !password) return;
    setLoading(true); setError(null);
    const result = mode === 'signin' ? await signInWithEmail(email, password) : await signUpWithEmail(email, password, name);
    setLoading(false);
    if (result.error) setError(result.error);
    else router.replace('/(app)/(tabs)');
  };

  return (
    <LinearGradient colors={['#0f172a', '#1e1b4b', '#0f172a']} style={styles.container}>
      <MotiView from={{ opacity: 0.3, scale: 0.8 }} animate={{ opacity: 0.5, scale: 1.1 }} transition={{ type: 'timing', duration: 3000, loop: true }} style={[styles.orb, { top: -80, right: -80, backgroundColor: '#6366f180', width: 260, height: 260 }]} />
      <MotiView from={{ opacity: 0.2, scale: 1 }} animate={{ opacity: 0.4, scale: 0.9 }} transition={{ type: 'timing', duration: 4000, loop: true }} style={[styles.orb, { bottom: 60, left: -60, backgroundColor: '#a855f740', width: 200, height: 200 }]} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={[styles.scroll, { minHeight: height }]} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <MotiView from={{ opacity: 0, translateY: -20 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 100 }} style={styles.logo}>
            <LinearGradient colors={[Colors.primary, Colors.secondary]} style={styles.logoBox}>
              <Ionicons name="school" size={20} color="white" />
            </LinearGradient>
            <Text style={styles.logoText}>Scholarly</Text>
          </MotiView>

          {mode === 'landing' ? (
            <>
              <MotiView from={{ opacity: 0, translateY: 30 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 200 }} style={styles.hero}>
                <Text style={styles.heroTitle}>Study smarter,{'\n'}<Text style={{ color: Colors.primaryLight }}>not harder.</Text></Text>
                <Text style={styles.heroSub}>Your all-in-one academic companion — track grades, manage homework, and get AI-powered study tools.</Text>
              </MotiView>
              <MotiView from={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 350 }} style={styles.pills}>
                {features.map((f, i) => (
                  <MotiView key={f.label} from={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 400 + i * 80 }}>
                    <View style={styles.pill}><Text style={styles.pillEmoji}>{f.emoji}</Text><Text style={styles.pillLabel}>{f.label}</Text></View>
                  </MotiView>
                ))}
              </MotiView>
              <MotiView from={{ opacity: 0, translateY: 30 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 500 }} style={styles.cta}>
                <TouchableOpacity style={styles.googleBtn} onPress={signInWithGoogle} activeOpacity={0.9}>
                  <Text style={styles.googleG}>G</Text>
                  <Text style={styles.googleText}>Continue with Google</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.appleBtn} onPress={signInWithApple} activeOpacity={0.9}>
                  <Ionicons name="logo-apple" size={20} color="white" />
                  <Text style={styles.socialText}>Continue with Apple</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.emailBtn} onPress={() => setMode('signin')} activeOpacity={0.9}>
                  <Ionicons name="mail-outline" size={18} color="rgba(255,255,255,0.8)" />
                  <Text style={styles.emailText}>Continue with Email</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setMode('signup')}><Text style={styles.createText}>Create a free account</Text></TouchableOpacity>
                <Text style={styles.legal}>By continuing, you agree to our Terms & Privacy Policy.{'\n'}Your data is private and secure.</Text>
              </MotiView>
            </>
          ) : (
            <MotiView from={{ opacity: 0, translateY: 20 }} animate={{ opacity: 1, translateY: 0 }} style={styles.form}>
              <Text style={styles.formTitle}>{mode === 'signin' ? 'Welcome back' : 'Create account'}</Text>
              {mode === 'signup' && <TextInput style={styles.input} placeholder="Full name" placeholderTextColor="rgba(255,255,255,0.35)" value={name} onChangeText={setName} autoCapitalize="words" />}
              <TextInput style={styles.input} placeholder="Email address" placeholderTextColor="rgba(255,255,255,0.35)" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
              <View style={{ position: 'relative' }}>
                <TextInput style={styles.input} placeholder="Password" placeholderTextColor="rgba(255,255,255,0.35)" value={password} onChangeText={setPassword} secureTextEntry={!showPw} />
                <TouchableOpacity style={styles.eyeBtn} onPress={() => setShowPw(v => !v)}>
                  <Ionicons name={showPw ? 'eye-off-outline' : 'eye-outline'} size={20} color="rgba(255,255,255,0.4)" />
                </TouchableOpacity>
              </View>
              {error && <Text style={styles.errorText}>{error}</Text>}
              <TouchableOpacity style={styles.submitBtn} onPress={handleAuth} disabled={loading} activeOpacity={0.9}>
                {loading ? <ActivityIndicator color="white" /> : <Text style={styles.submitText}>{mode === 'signin' ? 'Sign in' : 'Create account'}</Text>}
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setMode(mode === 'signin' ? 'signup' : 'signin')} style={{ marginTop: 12 }}>
                <Text style={styles.switchText}>{mode === 'signin' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setMode('landing')} style={{ marginTop: 8 }}>
                <Text style={styles.backText}>← Back</Text>
              </TouchableOpacity>
            </MotiView>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flexGrow: 1, paddingHorizontal: 24, paddingVertical: 60, alignItems: 'center', justifyContent: 'space-between' },
  orb: { position: 'absolute', borderRadius: 999 },
  logo: { flexDirection: 'row', alignItems: 'center', gap: 10, zIndex: 10, marginBottom: 8 },
  logoBox: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  logoText: { fontSize: 20, fontWeight: '700', color: 'white', letterSpacing: -0.5 },
  hero: { alignItems: 'center', zIndex: 10, marginVertical: 20 },
  heroTitle: { fontSize: 36, fontWeight: '800', color: 'white', textAlign: 'center', lineHeight: 44, letterSpacing: -0.5 },
  heroSub: { fontSize: 14, color: '#94a3b8', textAlign: 'center', lineHeight: 22, marginTop: 12, maxWidth: 300 },
  pills: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8, zIndex: 10, marginBottom: 20 },
  pill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999, backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' },
  pillEmoji: { fontSize: 13 },
  pillLabel: { fontSize: 12, color: 'rgba(255,255,255,0.8)', fontWeight: '500' },
  cta: { width: '100%', gap: 10, zIndex: 10 },
  googleBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, height: 54, borderRadius: 20, backgroundColor: 'white' },
  googleG: { fontSize: 18, fontWeight: '700', color: '#4285F4' },
  googleText: { fontSize: 15, fontWeight: '600', color: '#1e293b' },
  appleBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, height: 54, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.12)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  socialText: { fontSize: 15, fontWeight: '600', color: 'white' },
  emailBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, height: 54, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.07)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)' },
  emailText: { fontSize: 14, fontWeight: '500', color: 'rgba(255,255,255,0.8)' },
  createText: { textAlign: 'center', fontSize: 13, color: Colors.primaryLight, fontWeight: '500' },
  legal: { fontSize: 11, color: '#475569', textAlign: 'center', lineHeight: 17, marginTop: 4 },
  form: { width: '100%', zIndex: 10, marginTop: 20 },
  formTitle: { fontSize: 28, fontWeight: '700', color: 'white', textAlign: 'center', marginBottom: 24 },
  input: { width: '100%', height: 52, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', color: 'white', paddingHorizontal: 16, fontSize: 14, marginBottom: 10 },
  eyeBtn: { position: 'absolute', right: 12, top: 14 },
  errorText: { color: '#f87171', fontSize: 12, textAlign: 'center', marginBottom: 8 },
  submitBtn: { height: 52, borderRadius: 14, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  submitText: { fontSize: 15, fontWeight: '600', color: 'white' },
  switchText: { textAlign: 'center', fontSize: 12, color: 'rgba(255,255,255,0.5)' },
  backText: { textAlign: 'center', fontSize: 12, color: 'rgba(255,255,255,0.3)' },
});
