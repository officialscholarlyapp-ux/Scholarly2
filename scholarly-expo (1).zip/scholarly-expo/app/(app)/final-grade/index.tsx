import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { MotiView } from 'moti';
import { Colors } from '@/constants/theme';

interface GradeCategory { name: string; weight: string; currentGrade: string }

export default function FinalGradeScreen() {
  const [currentGrade, setCurrentGrade] = useState('');
  const [finalWeight, setFinalWeight] = useState('');
  const [desiredGrade, setDesiredGrade] = useState('');
  const [categories, setCategories] = useState<GradeCategory[]>([{ name: 'Homework', weight: '20', currentGrade: '' }, { name: 'Midterm', weight: '30', currentGrade: '' }, { name: 'Final Exam', weight: '50', currentGrade: '' }]);
  const [mode, setMode] = useState<'simple' | 'weighted'>('simple');

  // Simple mode: what grade needed on final
  const neededGrade = (() => {
    const cur = parseFloat(currentGrade);
    const fw = parseFloat(finalWeight);
    const dg = parseFloat(desiredGrade);
    if (isNaN(cur) || isNaN(fw) || isNaN(dg) || fw <= 0 || fw >= 100) return null;
    const currentWeight = 100 - fw;
    const needed = (dg - (cur * currentWeight / 100)) / (fw / 100);
    return needed;
  })();

  // Weighted mode
  const weightedAvg = (() => {
    const filled = categories.filter(c => c.currentGrade && c.weight);
    if (filled.length === 0) return null;
    const totalWeight = filled.reduce((s, c) => s + parseFloat(c.weight || '0'), 0);
    if (totalWeight === 0) return null;
    const weightedSum = filled.reduce((s, c) => s + parseFloat(c.currentGrade) * parseFloat(c.weight), 0);
    return weightedSum / totalWeight;
  })();

  const getColor = (grade: number | null) => {
    if (grade === null) return Colors.dark.foregroundMuted;
    if (grade >= 90) return Colors.accent;
    if (grade >= 70) return Colors.warning;
    return Colors.destructive;
  };

  const getLabel = (grade: number | null) => {
    if (grade === null) return '—';
    if (grade > 100) return 'Need extra credit 😅';
    if (grade < 0) return 'Already there! 🎉';
    return `${grade.toFixed(1)}%`;
  };

  const addCategory = () => setCategories(c => [...c, { name: '', weight: '', currentGrade: '' }]);
  const updateCategory = (i: number, field: keyof GradeCategory, value: string) => setCategories(c => c.map((cat, idx) => idx === i ? { ...cat, [field]: value } : cat));
  const removeCategory = (i: number) => setCategories(c => c.filter((_, idx) => idx !== i));

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.topBar}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><Ionicons name="chevron-down" size={24} color={Colors.dark.foreground} /></TouchableOpacity>
        <Text style={s.topTitle}>Final Grade Calculator</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={s.modePicker}>
          {(['simple', 'weighted'] as const).map(m => (
            <TouchableOpacity key={m} style={[s.modeBtn, mode === m && s.modeBtnActive]} onPress={() => setMode(m)}>
              <Text style={[s.modeBtnText, mode === m && s.modeBtnTextActive]}>{m === 'simple' ? 'What do I need?' : 'Weighted Average'}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {mode === 'simple' ? (
          <MotiView from={{ opacity: 0, translateY: 10 }} animate={{ opacity: 1, translateY: 0 }}>
            <Text style={s.modeDesc}>Find out what grade you need on the final exam to hit your target.</Text>
            <View style={s.inputGroup}>
              <Text style={s.inputLabel}>Current Grade (%)</Text>
              <TextInput style={s.inp} placeholder="e.g. 78" placeholderTextColor={Colors.dark.foregroundSubtle} value={currentGrade} onChangeText={setCurrentGrade} keyboardType="decimal-pad" />
            </View>
            <View style={s.inputGroup}>
              <Text style={s.inputLabel}>Final Exam Weight (%)</Text>
              <TextInput style={s.inp} placeholder="e.g. 30" placeholderTextColor={Colors.dark.foregroundSubtle} value={finalWeight} onChangeText={setFinalWeight} keyboardType="decimal-pad" />
            </View>
            <View style={s.inputGroup}>
              <Text style={s.inputLabel}>Desired Final Grade (%)</Text>
              <TextInput style={s.inp} placeholder="e.g. 90" placeholderTextColor={Colors.dark.foregroundSubtle} value={desiredGrade} onChangeText={setDesiredGrade} keyboardType="decimal-pad" />
            </View>
            {neededGrade !== null && (
              <MotiView from={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
                <LinearGradient colors={neededGrade <= 100 ? [Colors.primary, Colors.secondary] : [Colors.destructive, '#f97316']} style={s.resultCard}>
                  <Text style={s.resultLabel}>You need on the final:</Text>
                  <Text style={s.resultValue}>{getLabel(neededGrade)}</Text>
                  <Text style={s.resultSub}>
                    {neededGrade < 0 ? "You've already reached your goal! Just pass the final." :
                      neededGrade > 100 ? "This goal may not be reachable. Try adjusting your target." :
                        neededGrade > 90 ? "That's a tough ask — start studying now! 📚" :
                          neededGrade > 70 ? "Very achievable with solid prep. You got this! 💪" :
                            "You have a comfortable cushion. Keep it up! 🎉"}
                  </Text>
                </LinearGradient>
              </MotiView>
            )}
            {/* Grade scale */}
            <View style={s.scaleCard}>
              <Text style={s.scaleTitle}>Common Grade Cutoffs</Text>
              {[['A', '90%+'], ['B', '80–89%'], ['C', '70–79%'], ['D', '60–69%'], ['F', 'Below 60%']].map(([g, r]) => (
                <View key={g} style={s.scaleRow}><Text style={s.scaleGrade}>{g}</Text><Text style={s.scaleRange}>{r}</Text></View>
              ))}
            </View>
          </MotiView>
        ) : (
          <MotiView from={{ opacity: 0, translateY: 10 }} animate={{ opacity: 1, translateY: 0 }}>
            <Text style={s.modeDesc}>Calculate your overall grade based on weighted categories.</Text>
            {categories.map((cat, i) => (
              <View key={i} style={s.catRow}>
                <TextInput style={[s.inp, { flex: 2, marginBottom: 0 }]} placeholder="Category" placeholderTextColor={Colors.dark.foregroundSubtle} value={cat.name} onChangeText={t => updateCategory(i, 'name', t)} />
                <TextInput style={[s.inp, { flex: 1, marginBottom: 0, textAlign: 'center' }]} placeholder="Wt%" placeholderTextColor={Colors.dark.foregroundSubtle} value={cat.weight} onChangeText={t => updateCategory(i, 'weight', t)} keyboardType="decimal-pad" />
                <TextInput style={[s.inp, { flex: 1, marginBottom: 0, textAlign: 'center' }]} placeholder="Gr%" placeholderTextColor={Colors.dark.foregroundSubtle} value={cat.currentGrade} onChangeText={t => updateCategory(i, 'currentGrade', t)} keyboardType="decimal-pad" />
                <TouchableOpacity onPress={() => removeCategory(i)}><Ionicons name="close" size={18} color={Colors.destructive} /></TouchableOpacity>
              </View>
            ))}
            <TouchableOpacity style={s.addCatBtn} onPress={addCategory}>
              <Ionicons name="add" size={16} color={Colors.dark.foregroundMuted} />
              <Text style={s.addCatText}>Add Category</Text>
            </TouchableOpacity>
            {weightedAvg !== null && (
              <MotiView from={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
                <LinearGradient colors={[Colors.primary, Colors.secondary]} style={s.resultCard}>
                  <Text style={s.resultLabel}>Current Weighted Average:</Text>
                  <Text style={s.resultValue}>{weightedAvg.toFixed(1)}%</Text>
                  <Text style={s.resultSub}>{weightedAvg >= 90 ? '🎉 A range — excellent!' : weightedAvg >= 80 ? '👍 B range — solid work!' : weightedAvg >= 70 ? '📚 C range — room to improve' : '⚠️ Below passing — let\'s get to work'}</Text>
                </LinearGradient>
              </MotiView>
            )}
          </MotiView>
        )}
        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 16, fontWeight: '700', color: Colors.dark.foreground },
  content: { paddingHorizontal: 20 },
  modePicker: { flexDirection: 'row', backgroundColor: Colors.dark.card, borderRadius: 14, padding: 4, marginBottom: 20, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  modeBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  modeBtnActive: { backgroundColor: Colors.primary },
  modeBtnText: { fontSize: 13, fontWeight: '600', color: Colors.dark.foregroundMuted },
  modeBtnTextActive: { color: 'white' },
  modeDesc: { fontSize: 13, color: Colors.dark.foregroundMuted, marginBottom: 20, lineHeight: 18 },
  inputGroup: { marginBottom: 16 },
  inputLabel: { fontSize: 13, color: Colors.dark.foregroundMuted, marginBottom: 6, fontWeight: '500' },
  inp: { backgroundColor: Colors.dark.card, borderRadius: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, paddingHorizontal: 16, paddingVertical: 14, fontSize: 14, color: Colors.dark.foreground, marginBottom: 12 },
  resultCard: { borderRadius: 20, padding: 24, alignItems: 'center', gap: 8, marginBottom: 20 },
  resultLabel: { fontSize: 13, color: 'rgba(255,255,255,0.8)', fontWeight: '600' },
  resultValue: { fontSize: 52, fontWeight: '800', color: 'white', letterSpacing: -1 },
  resultSub: { fontSize: 13, color: 'rgba(255,255,255,0.8)', textAlign: 'center', lineHeight: 18 },
  scaleCard: { backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  scaleTitle: { fontSize: 12, fontWeight: '600', color: Colors.dark.foregroundMuted, marginBottom: 12 },
  scaleRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: Colors.dark.cardBorder },
  scaleGrade: { fontSize: 14, fontWeight: '700', color: Colors.primary },
  scaleRange: { fontSize: 13, color: Colors.dark.foregroundMuted },
  catRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  addCatBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderWidth: 1.5, borderStyle: 'dashed', borderColor: Colors.dark.cardBorder, borderRadius: 14, paddingVertical: 12, marginBottom: 20 },
  addCatText: { fontSize: 13, color: Colors.dark.foregroundMuted },
});
