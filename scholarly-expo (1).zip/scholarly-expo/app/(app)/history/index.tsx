import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { format } from 'date-fns';
import { useAIHistory } from '@/hooks/use-data';
import type { AIHistory, AIHistoryType } from '@/types/database';
import { Colors } from '@/constants/theme';

const TYPE_META: Record<AIHistoryType, { label: string; icon: React.ComponentProps<typeof Ionicons>['name']; color: string }> = {
  quiz: { label: 'Practice Quiz', icon: 'flask-outline', color: Colors.accent },
  flashcards: { label: 'Flashcards', icon: 'duplicate-outline', color: Colors.primary },
  summary: { label: 'Summary', icon: 'document-text-outline', color: Colors.chart3 },
  study_guide: { label: 'Study Guide', icon: 'list-outline', color: Colors.chart4 },
  teacher_analyzer: { label: 'Teacher Analysis', icon: 'people-outline', color: Colors.secondary },
  get_an_a: { label: 'Get an A Plan', icon: 'school-outline', color: Colors.warning },
};

const FILTERS: { id: AIHistoryType | 'all'; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'quiz', label: 'Quizzes' },
  { id: 'flashcards', label: 'Flashcards' },
  { id: 'summary', label: 'Summaries' },
  { id: 'study_guide', label: 'Guides' },
  { id: 'teacher_analyzer', label: 'Teachers' },
  { id: 'get_an_a', label: 'A Plans' },
];

export default function HistoryScreen() {
  const { data: history, remove } = useAIHistory();
  const [filter, setFilter] = useState<AIHistoryType | 'all'>('all');
  const [selected, setSelected] = useState<AIHistory | null>(null);

  const filtered = filter === 'all' ? history : history.filter(h => h.type === filter);

  const renderResult = (item: AIHistory) => {
    const result = item.result as any;
    if (!result) return <Text style={s.detailText}>No content saved.</Text>;
    if (result.questions) return result.questions.slice(0, 3).map((q: any, i: number) => (
      <View key={i} style={s.previewItem}><Text style={s.previewLabel}>Q{i + 1}</Text><Text style={s.previewText}>{q.question}</Text></View>
    ));
    if (result.flashcards) return result.flashcards.slice(0, 3).map((f: any, i: number) => (
      <View key={i} style={s.previewItem}><Text style={[s.previewLabel, { color: Colors.primary }]}>{f.term}</Text><Text style={s.previewText}>{f.definition}</Text></View>
    ));
    if (result.summary) return <Text style={s.detailText}>{result.summary.slice(0, 400)}{result.summary.length > 400 ? '...' : ''}</Text>;
    if (result.study_guide) return <Text style={s.detailText}>{result.study_guide.slice(0, 400)}{result.study_guide.length > 400 ? '...' : ''}</Text>;
    if (result.current_standing) return (
      <>
        <Text style={s.detailText}>{result.current_standing}</Text>
        {result.winning_strategies?.slice(0, 2).map((st: string, i: number) => (
          <View key={i} style={s.previewItem}><View style={s.bullet} /><Text style={s.previewText}>{st}</Text></View>
        ))}
      </>
    );
    return <Text style={s.detailText}>{JSON.stringify(result).slice(0, 200)}...</Text>;
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.topBar}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><Ionicons name="chevron-back" size={24} color={Colors.dark.foreground} /></TouchableOpacity>
        <Text style={s.topTitle}>AI History</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.filters}>
        {FILTERS.map(f => (
          <TouchableOpacity key={f.id} style={[s.pill, filter === f.id && s.pillActive]} onPress={() => setFilter(f.id)}>
            <Text style={[s.pillText, filter === f.id && s.pillTextActive]}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false}>
        {filtered.map((item, i) => {
          const meta = TYPE_META[item.type];
          return (
            <MotiView key={item.id} from={{ opacity: 0, translateY: 8 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: i * 30 }}>
              <TouchableOpacity style={s.card} onPress={() => setSelected(item)} activeOpacity={0.85}>
                <View style={[s.iconWrap, { backgroundColor: `${meta.color}20` }]}>
                  <Ionicons name={meta.icon} size={20} color={meta.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.cardTitle} numberOfLines={1}>{item.title || meta.label}</Text>
                  <Text style={s.cardSub}>{meta.label} · {format(new Date(item.created_at), 'MMM d, yyyy')}</Text>
                  {item.input_summary && <Text style={s.cardPreview} numberOfLines={1}>{item.input_summary}</Text>}
                </View>
                <TouchableOpacity onPress={() => remove.mutate(item.id)} style={{ padding: 4 }}>
                  <Ionicons name="trash-outline" size={16} color={Colors.dark.foregroundSubtle} />
                </TouchableOpacity>
              </TouchableOpacity>
            </MotiView>
          );
        })}
        {filtered.length === 0 && (
          <View style={s.empty}>
            <Ionicons name="time-outline" size={48} color={Colors.dark.foregroundSubtle} />
            <Text style={s.emptyTitle}>No history yet</Text>
            <Text style={s.emptySub}>Your AI-generated content will appear here.</Text>
          </View>
        )}
        <View style={{ height: 100 }} />
      </ScrollView>

      <Modal visible={!!selected} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setSelected(null)}>
        {selected && (
          <SafeAreaView style={s.modal} edges={['top']}>
            <View style={s.modalHeader}>
              <View style={{ flex: 1 }}>
                <Text style={s.modalTitle}>{selected.title || TYPE_META[selected.type].label}</Text>
                <Text style={s.modalSub}>{TYPE_META[selected.type].label} · {format(new Date(selected.created_at), 'MMM d, yyyy')}</Text>
              </View>
              <TouchableOpacity onPress={() => setSelected(null)}><Ionicons name="close" size={24} color={Colors.dark.foregroundMuted} /></TouchableOpacity>
            </View>
            <ScrollView contentContainerStyle={{ padding: 20 }}>
              {renderResult(selected)}
              <View style={{ height: 40 }} />
            </ScrollView>
          </SafeAreaView>
        )}
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground },
  filters: { paddingHorizontal: 20, paddingBottom: 12, gap: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, backgroundColor: Colors.dark.card, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  pillActive: { backgroundColor: `${Colors.primary}20`, borderColor: `${Colors.primary}50` },
  pillText: { fontSize: 12, color: Colors.dark.foregroundMuted, fontWeight: '500' },
  pillTextActive: { color: Colors.primary },
  content: { paddingHorizontal: 20 },
  card: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: Colors.dark.card, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 8 },
  iconWrap: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  cardTitle: { fontSize: 14, fontWeight: '600', color: Colors.dark.foreground },
  cardSub: { fontSize: 11, color: Colors.dark.foregroundMuted, marginTop: 2 },
  cardPreview: { fontSize: 11, color: Colors.dark.foregroundSubtle, marginTop: 3 },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground },
  emptySub: { fontSize: 13, color: Colors.dark.foregroundMuted, textAlign: 'center', maxWidth: 260, lineHeight: 20 },
  modal: { flex: 1, backgroundColor: Colors.dark.background },
  modalHeader: { flexDirection: 'row', alignItems: 'flex-start', padding: 20, borderBottomWidth: 1, borderBottomColor: Colors.dark.cardBorder },
  modalTitle: { fontSize: 18, fontWeight: '700', color: Colors.dark.foreground },
  modalSub: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  detailText: { fontSize: 14, color: Colors.dark.foreground, lineHeight: 22 },
  previewItem: { marginBottom: 12 },
  previewLabel: { fontSize: 11, fontWeight: '700', color: Colors.accent, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 },
  previewText: { fontSize: 13, color: Colors.dark.foreground, lineHeight: 20 },
  bullet: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.primary, marginTop: 7 },
});
