import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { format, isToday, isTomorrow, isPast } from 'date-fns';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useHomework } from '@/hooks/use-data';
import type { HomeworkStatus } from '@/types/database';
import { Colors } from '@/constants/theme';

const FILTERS = ['all', 'active', 'todo', 'in_progress', 'done'] as const;
const PRI = { high: Colors.destructive, medium: Colors.warning, low: Colors.dark.foregroundSubtle };

export default function HomeworkScreen() {
  const { data: homework, create, update, remove } = useHomework();
  const [filter, setFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [form, setForm] = useState({ title: '', subject: '', due_date: null as Date | null, priority: 'medium' as 'low' | 'medium' | 'high' });

  const filtered = homework.filter(h => filter === 'all' ? true : filter === 'active' ? h.status !== 'done' : h.status === filter);
  const next = (s: HomeworkStatus): HomeworkStatus => s === 'todo' ? 'in_progress' : s === 'in_progress' ? 'done' : 'todo';

  const submit = () => {
    if (!form.title.trim()) return;
    create.mutate({ title: form.title, subject: form.subject || null, due_date: form.due_date ? form.due_date.toISOString().split('T')[0] : null, priority: form.priority, status: 'todo', description: null });
    setForm({ title: '', subject: '', due_date: null, priority: 'medium' });
    setShowModal(false);
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.header}>
        <View>
          <Text style={s.title}>Homework Planner</Text>
          <Text style={s.sub}>Never miss a deadline</Text>
        </View>
        <TouchableOpacity style={s.addBtn} onPress={() => setShowModal(true)}>
          <Ionicons name="add" size={22} color="white" />
        </TouchableOpacity>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.filters}>
        {FILTERS.map(f => (
          <TouchableOpacity key={f} style={[s.pill, filter === f && s.pillActive]} onPress={() => setFilter(f)}>
            <Text style={[s.pillText, filter === f && s.pillTextActive]}>{f === 'in_progress' ? 'In Progress' : f.charAt(0).toUpperCase() + f.slice(1)}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 8 }} showsVerticalScrollIndicator={false}>
        {filtered.map((hw, i) => (
          <MotiView key={hw.id} from={{ opacity: 0, translateY: 8 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: i * 30 }}>
            <View style={[s.card, hw.status === 'done' && { opacity: 0.55 }]}>
              <TouchableOpacity onPress={() => update.mutate({ id: hw.id, data: { status: next(hw.status) } })}>
                <Ionicons name={hw.status === 'done' ? 'checkmark-circle' : hw.status === 'in_progress' ? 'time' : 'ellipse-outline'} size={24} color={hw.status === 'done' ? Colors.accent : hw.status === 'in_progress' ? Colors.warning : Colors.dark.foregroundSubtle} />
              </TouchableOpacity>
              <View style={{ flex: 1 }}>
                <Text style={[s.hwTitle, hw.status === 'done' && s.hwDone]}>{hw.title}</Text>
                <View style={s.meta}>
                  {hw.subject && <Text style={s.hwSub}>{hw.subject}</Text>}
                  {hw.due_date && (() => { const d = new Date(hw.due_date); const over = isPast(d) && !isToday(d); return <View style={[s.badge, over && s.badgeRed]}><Text style={[s.badgeText, over && s.badgeTextRed]}>{isToday(d) ? 'Today' : isTomorrow(d) ? 'Tomorrow' : format(d, 'MMM d')}</Text></View>; })()}
                  <View style={[s.dot, { backgroundColor: PRI[hw.priority] }]} />
                </View>
              </View>
              <TouchableOpacity onPress={() => remove.mutate(hw.id)}><Ionicons name="trash-outline" size={16} color={Colors.dark.foregroundSubtle} /></TouchableOpacity>
            </View>
          </MotiView>
        ))}
        {filtered.length === 0 && <View style={s.empty}><Text style={s.emptyText}>No assignments. Tap + to add one.</Text></View>}
        <View style={{ height: 100 }} />
      </ScrollView>
      <Modal visible={showModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowModal(false)}>
        <View style={s.modal}>
          <View style={s.modalHeader}>
            <Text style={s.modalTitle}>Add Assignment</Text>
            <TouchableOpacity onPress={() => setShowModal(false)}><Ionicons name="close" size={24} color={Colors.dark.foregroundMuted} /></TouchableOpacity>
          </View>
          <TextInput style={s.inp} placeholder="Title *" placeholderTextColor={Colors.dark.foregroundSubtle} value={form.title} onChangeText={t => setForm(f => ({ ...f, title: t }))} />
          <TextInput style={s.inp} placeholder="Subject (optional)" placeholderTextColor={Colors.dark.foregroundSubtle} value={form.subject} onChangeText={t => setForm(f => ({ ...f, subject: t }))} />
          <TouchableOpacity style={s.inp} onPress={() => setShowDatePicker(true)}>
            <Text style={{ color: form.due_date ? Colors.dark.foreground : Colors.dark.foregroundSubtle }}>{form.due_date ? format(form.due_date, 'MMM d, yyyy') : 'Due date (optional)'}</Text>
          </TouchableOpacity>
          {showDatePicker && <DateTimePicker value={form.due_date ?? new Date()} mode="date" onChange={(_, d) => { setShowDatePicker(false); if (d) setForm(f => ({ ...f, due_date: d })); }} />}
          <View style={s.priRow}>
            {(['low', 'medium', 'high'] as const).map(p => (
              <TouchableOpacity key={p} style={[s.priBtn, form.priority === p && { backgroundColor: PRI[p], borderColor: PRI[p] }]} onPress={() => setForm(f => ({ ...f, priority: p }))}>
                <Text style={[s.priBtnText, form.priority === p && { color: 'white' }]}>{p.charAt(0).toUpperCase() + p.slice(1)}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity style={s.submitBtn} onPress={submit} disabled={!form.title.trim()}>
            <Text style={s.submitText}>Add Assignment</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 8, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: '700', color: Colors.dark.foreground },
  sub: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  addBtn: { width: 40, height: 40, borderRadius: 14, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  filters: { paddingHorizontal: 20, paddingBottom: 12, gap: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, backgroundColor: Colors.dark.card, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  pillActive: { backgroundColor: `${Colors.primary}20`, borderColor: `${Colors.primary}50` },
  pillText: { fontSize: 12, color: Colors.dark.foregroundMuted, fontWeight: '500' },
  pillTextActive: { color: Colors.primary },
  card: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.dark.card, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 8 },
  hwTitle: { fontSize: 14, fontWeight: '600', color: Colors.dark.foreground },
  hwDone: { textDecorationLine: 'line-through', color: Colors.dark.foregroundMuted },
  meta: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4, flexWrap: 'wrap' },
  hwSub: { fontSize: 11, color: Colors.dark.foregroundMuted },
  badge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  badgeRed: { borderColor: `${Colors.destructive}50`, backgroundColor: `${Colors.destructive}10` },
  badgeText: { fontSize: 10, fontFamily: 'monospace', color: Colors.dark.foregroundMuted },
  badgeTextRed: { color: Colors.destructive },
  dot: { width: 6, height: 6, borderRadius: 3 },
  empty: { alignItems: 'center', paddingVertical: 60 },
  emptyText: { fontSize: 13, color: Colors.dark.foregroundMuted },
  modal: { flex: 1, backgroundColor: Colors.dark.background, padding: 24 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: Colors.dark.foreground },
  inp: { backgroundColor: Colors.dark.card, borderRadius: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, paddingHorizontal: 16, paddingVertical: 14, fontSize: 14, color: Colors.dark.foreground, marginBottom: 12 },
  priRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  priBtn: { flex: 1, paddingVertical: 10, borderRadius: 12, borderWidth: 1.5, borderColor: Colors.dark.cardBorder, alignItems: 'center' },
  priBtnText: { fontSize: 13, fontWeight: '600', color: Colors.dark.foregroundMuted },
  submitBtn: { backgroundColor: Colors.primary, borderRadius: 16, paddingVertical: 16, alignItems: 'center' },
  submitText: { fontSize: 16, fontWeight: '700', color: 'white' },
});
