import { Tabs } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

function TabIcon({ name, focused }: { name: IconName; focused: boolean }) {
  return (
    <View style={[styles.icon, focused && styles.iconActive]}>
      <Ionicons name={name} size={22} color={focused ? Colors.primary : Colors.dark.foregroundSubtle} />
    </View>
  );
}

export default function TabLayout() {
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarStyle: styles.tabBar, tabBarShowLabel: false, tabBarBackground: () => <View style={[StyleSheet.absoluteFill, styles.tabBg]} /> }}>
      <Tabs.Screen name="index" options={{ tabBarIcon: ({ focused }) => <TabIcon name={focused ? 'home' : 'home-outline'} focused={focused} /> }} />
      <Tabs.Screen name="gpa" options={{ tabBarIcon: ({ focused }) => <TabIcon name={focused ? 'trending-up' : 'trending-up-outline'} focused={focused} /> }} />
      <Tabs.Screen name="homework" options={{ tabBarIcon: ({ focused }) => <TabIcon name={focused ? 'book' : 'book-outline'} focused={focused} /> }} />
      <Tabs.Screen name="reminders" options={{ tabBarIcon: ({ focused }) => <TabIcon name={focused ? 'notifications' : 'notifications-outline'} focused={focused} /> }} />
      <Tabs.Screen name="more" options={{ tabBarIcon: ({ focused }) => <TabIcon name={focused ? 'grid' : 'grid-outline'} focused={focused} /> }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: { position: 'absolute', borderTopWidth: 0, height: 80, paddingBottom: 16, paddingTop: 8, backgroundColor: 'transparent', elevation: 0 },
  tabBg: { backgroundColor: `${Colors.dark.card}F2`, borderTopWidth: 1, borderTopColor: Colors.dark.cardBorder },
  icon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  iconActive: { backgroundColor: `${Colors.primary}20` },
});
