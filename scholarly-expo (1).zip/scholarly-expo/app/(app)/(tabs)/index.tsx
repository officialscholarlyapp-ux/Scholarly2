import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { format } from 'date-fns';
import { useClasses, useHomework } from '@/hooks/use-data';
import { useAuth } from '@/lib/auth-context';
import { Colors } from '@/constants/theme';

const { width } = Dimensions.get('window');

const quickActions = [
  { path: '/(app)/(tabs)/gpa', label: 'GPA Calculator', icon: 'trending-up' as const, colors: [Colors.primary, Colors.secondary] as [string,string], desc: 'Track grades' },
  { path: '/(app)/(tabs)/homework', label: 'Homework', icon: 'book-outline' as const, colors: ['#f59e0b', '#f97316'] as [string,string], desc: 'Manage tasks' },
  { path: '/(app)/quiz-maker', label: 'Notes → Quiz', icon: 'flask-outline' as const, colors: [Colors.accent, '#34d399'] as [string,string], desc: 'AI-powered', premium: true },
  { path: '/(app)/get-an-a', label: 'Get an A', icon: 'school-outline' as const, colors: [Colors.secondary, '#ec4899'] as [string,string], desc: 'Game plan', premium: true },
  { path: '/(app)/final-grade', label: 'Final Grade', icon: 'calculator-outline' as const, colors: ['#06b6d4', '#3b82f6'] as [string,string], desc: 'What do I need?' },
  { path: '/(app)/(tabs)/reminders', label: 'Schedule', icon: 'notifications-outline' as const, colors: ['#8b5cf6', '#7c3aed'] as [string,string], desc: 'Class times' },
];

export default function DashboardScreen() {
  const { profile, isPremium } = useAuth();
  const { data: classes } = useClasses();
  const { data: homework } = useHomework();
  const withGrades = classes.filter(c => c.current_grade !== null);
  const gpa = withGrades.length > 0 ? withGrades.reduce((s, c) => s + (c.current_grade! >= 90 ? 4 : c.current_grade! >= 80 ? 3 : c.current_grade! >= 70 ? 2 : c.current_grade! >= 60 ? 1 : 0) * (c.credits || 3), 0) / withGrades.reduce((s, c) => s + (c.credits || 3), 0) : null;
  const pending = homework.filter(h => h.status !== 'done');
  const done = homework.filter(h => h.status === 'done');
  const completion = homework.length > 0 ? Math.round((done.length / homework.length) * 100) : 0;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const firstName = profile?.full_name?.split(' ')[0] ?? '';

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <MotiView from={{ opacity: 0, translateY: -16 }} animate={{ opacity: 1, translateY: 0 }}>
          <View style={styles.header}>
            <View style={{ flex: 1 }}>
              <Text style={styles.greeting}>{greeting}{firstName ? `, ${firstName}` : ''} 👋</Text>
              <Text style={styles.date}>{format(new Date(), 'EEEE, MMMM d, yyyy')}</Text>
            </View>
            <TouchableOpacity style={styles.avatar} onPress={() => router.push('/(app)/pricing')}>
              <Text style={styles.avatarText}>{profile?.full_name?.[0]?.toUpperCase() ?? '?'}</Text>
            </TouchableOpacity>
          </View>
        </MotiView>

        <MotiView from={{ opacity: 0, translateY: 20 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 100 }}>
          <LinearGradient colors={[Colors.primary, Colors.secondary, Colors.primaryDark]} style={styles.heroCard} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
            <View style={{ flex: 1 }}>
              <Text style={styles.heroLabel}>Current GPA</Text>
              <Text style={styles.heroGPA}>{gpa !== null ? gpa.toFixed(2) : '—'}</Text>
              <Text style={styles.heroSub}>{withGrades.length > 0 ? `Across ${withGrades.length} class${withGrades.length !== 1 ? 'es' : ''}` : 'Add classes to start tracking'}</Text>
              <TouchableOpacity style={styles.heroBtn} onPress={() => router.push('/(app)/(tabs)/gpa')}>
                <Text style={styles.heroBtnText}>View Details</Text>
                <Ionicons name="arrow-forward" size={14} color="white" />
              </TouchableOpacity>
            </View>
            <View style={{ gap: 8 }}>
              {withGrades.slice(0, 2).map(c => (
                <View key={c.id} style={styles.miniCard}>
                  <Text style={styles.miniNum}>{c.current_grade}%</Text>
                  <Text style={styles.miniName} numberOfLines={1}>{c.name}</Text>
                </View>
              ))}
            </View>
          </LinearGradient>
        </MotiView>

        <View style={styles.statsRow}>
          {[{ label: 'Pending', value: String(pending.length), color: Colors.warning }, { label: 'Done', value: `${completion}%`, color: Colors.accent }].map((s, i) => (
            <MotiView key={s.label} from={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 150 + i * 60 }} style={{ flex: 1 }}>
              <View style={styles.statCard}>
                <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </View>
            </MotiView>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Quick Access</Text>
        <View style={styles.actionsGrid}>
          {quickActions.map((a, i) => (
            <MotiView key={a.path} from={{ opacity: 0, scale: 0.85, translateY: 16 }} animate={{ opacity: 1, scale: 1, translateY: 0 }} transition={{ delay: 260 + i * 40 }} style={styles.actionWrap}>
              <TouchableOpacity style={styles.actionCard} onPress={() => router.push(a.path as any)} activeOpacity={0.85}>
                <LinearGradient colors={a.colors} style={styles.actionIcon}>
                  <Ionicons name={a.icon} size={20} color="white" />
                </LinearGradient>
                <Text style={styles.actionLabel}>{a.label}</Text>
                <Text style={styles.actionDesc}>{a.desc}</Text>
                {a.premium && !isPremium && <View style={styles.crownBadge}><Ionicons name="diamond-outline" size={10} color={Colors.warning} /></View>}
              </TouchableOpacity>
            </MotiView>
          ))}
        </View>

        {pending.length > 0 && (
          <MotiView from={{ opacity: 0, translateY: 16 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 400 }}>
            <View style={styles.sectionRow}>
              <Text style={styles.sectionTitle}>Coming Up</Text>
              <TouchableOpacity onPress={() => router.push('/(app)/(tabs)/homework')}><Text style={styles.seeAll}>See all</Text></TouchableOpacity>
            </View>
            {pending.slice(0, 3).map(hw => (
              <TouchableOpacity key={hw.id} style={styles.hwItem} onPress={() => router.push('/(app)/(tabs)/homework')} activeOpacity={0.8}>
                <View style={[styles.hwDot, { backgroundColor: hw.priority === 'high' ? Colors.destructive : hw.priority === 'medium' ? Colors.warning : Colors.dark.foregroundSubtle }]} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.hwTitle} numberOfLines={1}>{hw.title}</Text>
                  {hw.subject && <Text style={styles.hwSub}>{hw.subject}</Text>}
                </View>
                {hw.due_date && <Text style={styles.hwDate}>{format(new Date(hw.due_date), 'MMM d')}</Text>}
              </TouchableOpacity>
            ))}
          </MotiView>
        )}

        {!isPremium && (
          <TouchableOpacity onPress={() => router.push('/(app)/pricing')} style={styles.upgradeBanner} activeOpacity={0.9}>
            <View style={styles.upgradeIcon}><Ionicons name="diamond-outline" size={20} color={Colors.warning} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.upgradeTitle}>Unlock AI Study Tools</Text>
              <Text style={styles.upgradeSub}>Quiz maker, teacher analyzer & more</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color={Colors.primary} />
          </TouchableOpacity>
        )}
        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  content: { paddingHorizontal: 20, paddingTop: 8 },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  greeting: { fontSize: 22, fontWeight: '700', color: Colors.dark.foreground },
  date: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: `${Colors.primary}30`, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 16, fontWeight: '700', color: Colors.primary },
  heroCard: { borderRadius: 24, padding: 22, flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 16, shadowColor: Colors.primary, shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.3, shadowRadius: 16, elevation: 8 },
  heroLabel: { fontSize: 12, color: 'rgba(255,255,255,0.7)', fontWeight: '600', marginBottom: 4 },
  heroGPA: { fontSize: 52, fontWeight: '800', color: 'white', letterSpacing: -1 },
  heroSub: { fontSize: 12, color: 'rgba(255,255,255,0.6)', marginTop: 4 },
  heroBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 14, backgroundColor: 'rgba(255,255,255,0.2)', alignSelf: 'flex-start', paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999 },
  heroBtnText: { fontSize: 12, fontWeight: '600', color: 'white' },
  miniCard: { alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.15)', padding: 10, borderRadius: 14, minWidth: 60 },
  miniNum: { fontSize: 18, fontWeight: '700', color: 'white' },
  miniName: { fontSize: 10, color: 'rgba(255,255,255,0.7)', marginTop: 2, maxWidth: 58 },
  statsRow: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  statCard: { backgroundColor: Colors.dark.card, borderRadius: 20, padding: 18, alignItems: 'center', borderWidth: 1, borderColor: Colors.dark.cardBorder },
  statValue: { fontSize: 32, fontWeight: '800', letterSpacing: -0.5 },
  statLabel: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 4 },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: Colors.dark.foregroundSubtle, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 },
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  seeAll: { fontSize: 12, color: Colors.primary, fontWeight: '600' },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 28 },
  actionWrap: { width: (width - 52) / 3 },
  actionCard: { backgroundColor: Colors.dark.card, borderRadius: 20, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: Colors.dark.cardBorder },
  actionIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  actionLabel: { fontSize: 11, fontWeight: '600', color: Colors.dark.foreground, textAlign: 'center' },
  actionDesc: { fontSize: 10, color: Colors.dark.foregroundMuted, marginTop: 2, textAlign: 'center' },
  crownBadge: { position: 'absolute', top: 8, right: 8 },
  hwItem: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.dark.card, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 8 },
  hwDot: { width: 8, height: 8, borderRadius: 4 },
  hwTitle: { fontSize: 14, fontWeight: '600', color: Colors.dark.foreground },
  hwSub: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  hwDate: { fontSize: 11, fontFamily: 'monospace', color: Colors.dark.foregroundMuted },
  upgradeBanner: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: `${Colors.primary}15`, borderWidth: 1, borderColor: `${Colors.primary}30`, borderRadius: 20, padding: 16, marginTop: 8 },
  upgradeIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: `${Colors.warning}20`, alignItems: 'center', justifyContent: 'center' },
  upgradeTitle: { fontSize: 14, fontWeight: '700', color: Colors.dark.foreground },
  upgradeSub: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
});
