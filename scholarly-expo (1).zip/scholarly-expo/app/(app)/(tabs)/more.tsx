import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { MotiView } from 'moti';
import { useAuth } from '@/lib/auth-context';
import { Colors } from '@/constants/theme';

type IconName = React.ComponentProps<typeof Ionicons>['name'];
const menu = [
  { path: '/(app)/quiz-maker', label: 'Notes → Quiz', desc: 'Turn notes into practice questions', icon: 'flask-outline' as IconName, colors: [Colors.accent, '#34d399'] as [string,string], premium: true },
  { path: '/(app)/get-an-a', label: 'Get an A', desc: 'AI strategy to ace your class', icon: 'school-outline' as IconName, colors: [Colors.secondary, '#ec4899'] as [string,string], premium: true },
  { path: '/(app)/teacher-analyzer', label: 'Teacher Analyzer', desc: 'Understand your professor', icon: 'people-outline' as IconName, colors: ['#06b6d4', '#0ea5e9'] as [string,string], premium: true },
  { path: '/(app)/study-planner', label: 'Study Planner', desc: 'AI-powered study sessions', icon: 'calendar-outline' as IconName, colors: ['#8b5cf6', '#7c3aed'] as [string,string], premium: true },
  { path: '/(app)/final-grade', label: 'Final Grade Calc', desc: 'What grade do I need?', icon: 'calculator-outline' as IconName, colors: ['#06b6d4', '#3b82f6'] as [string,string] },
  { path: '/(app)/history', label: 'AI History', desc: 'Review past generations', icon: 'time-outline' as IconName, colors: [Colors.dark.foregroundSubtle, Colors.dark.foregroundMuted] as [string,string] },
  { path: '/(app)/pricing', label: 'Upgrade to Premium', desc: 'Unlock all AI tools', icon: 'diamond-outline' as IconName, colors: [Colors.warning, '#f97316'] as [string,string] },
];

export default function MoreScreen() {
  const { profile, isPremium, signOut } = useAuth();
  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false}>
        <MotiView from={{ opacity: 0, translateY: -12 }} animate={{ opacity: 1, translateY: 0 }}>
          <View style={s.profile}>
            <View style={s.avatar}><Text style={s.avatarText}>{profile?.full_name?.[0]?.toUpperCase() ?? '?'}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.name}>{profile?.full_name ?? 'Student'}</Text>
              <Text style={s.email}>{profile?.email}</Text>
            </View>
            {isPremium && <View style={s.proBadge}><Text style={s.proBadgeText}>PRO</Text></View>}
          </View>
        </MotiView>
        <Text style={s.sectionTitle}>Tools</Text>
        {menu.map((item, i) => (
          <MotiView key={item.path} from={{ opacity: 0, translateX: -12 }} animate={{ opacity: 1, translateX: 0 }} transition={{ delay: i * 40 }}>
            <TouchableOpacity style={s.item} onPress={() => router.push(item.path as any)} activeOpacity={0.8}>
              <LinearGradient colors={item.colors} style={s.itemIcon}>
                <Ionicons name={item.icon} size={20} color="white" />
              </LinearGradient>
              <View style={{ flex: 1 }}>
                <Text style={s.itemLabel}>{item.label}</Text>
                <Text style={s.itemDesc}>{item.desc}</Text>
              </View>
              {item.premium && !isPremium && <Ionicons name="diamond-outline" size={14} color={Colors.warning} />}
              <Ionicons name="chevron-forward" size={16} color={Colors.dark.foregroundSubtle} style={{ marginLeft: 4 }} />
            </TouchableOpacity>
          </MotiView>
        ))}
        <TouchableOpacity style={s.signOut} onPress={signOut}>
          <Ionicons name="log-out-outline" size={18} color={Colors.destructive} />
          <Text style={s.signOutText}>Sign Out</Text>
        </TouchableOpacity>
        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  content: { paddingHorizontal: 20, paddingTop: 8 },
  profile: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: Colors.dark.card, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 28 },
  avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: `${Colors.primary}30`, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 20, fontWeight: '700', color: Colors.primary },
  name: { fontSize: 15, fontWeight: '700', color: Colors.dark.foreground },
  email: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  proBadge: { backgroundColor: `${Colors.warning}20`, borderWidth: 1, borderColor: `${Colors.warning}40`, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  proBadgeText: { fontSize: 10, fontWeight: '800', color: Colors.warning, letterSpacing: 0.5 },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: Colors.dark.foregroundSubtle, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 },
  item: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: Colors.dark.card, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 8 },
  itemIcon: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  itemLabel: { fontSize: 14, fontWeight: '600', color: Colors.dark.foreground },
  itemDesc: { fontSize: 11, color: Colors.dark.foregroundMuted, marginTop: 2 },
  signOut: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 24, paddingVertical: 14, borderRadius: 16, borderWidth: 1.5, borderColor: `${Colors.destructive}30` },
  signOutText: { fontSize: 15, fontWeight: '600', color: Colors.destructive },
});
