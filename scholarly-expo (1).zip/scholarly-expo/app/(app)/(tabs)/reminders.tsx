import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { useClasses } from '@/hooks/use-data';
import type { Class } from '@/types/database';
import { Colors } from '@/constants/theme';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const CLS_COLORS = [Colors.primary, Colors.accent, Colors.chart3, Colors.chart4, Colors.chart5, Colors.destructive, Colors.secondary];

export default function RemindersScreen() {
  const { data: classes, create, remove } = useClasses();
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', teacher: '', reminder_days: [] as number[], reminder_time: '09:00 AM' });

  const withSchedule = classes.filter(c => c.reminder_days?.length > 0);
  const schedule = Array.from({ length: 7 }, (_, day) => ({ day, classes: withSchedule.filter(c => c.reminder_days?.includes(day)) }));

  const toggleDay = (d: number) => setForm(f => ({ ...f, reminder_days: f.reminder_days.includes(d) ? f.reminder_days.filter(x => x !== d) : [...f.reminder_days, d] }));

  const submit = () => {
    if (!form.name.trim()) return;
    create.mutate({ name: form.name, teacher: form.teacher || null, credits: 3, current_grade: null, is_weighted: false, color: 'bg-primary', reminder_days: form.reminder_days, reminder_time: form.reminder_time });
    setForm({ name: '', teacher: '', reminder_days: [], reminder_time: '09:00 AM' });
    setShowModal(false);
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.header}>
        <View>
          <Text style={s.title}>Class Schedule</Text>
          <Text style={s.subtitle}>Weekly view of your classes</Text>
        </View>
        <TouchableOpacity style={s.addBtn} onPress={() => setShowModal(true)}>
          <Ionicons name="add" size={22} color="white" />
        </TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false}>
        {schedule.map(({ day, classes: dc }, i) => (
          <MotiView key={day} from={{ opacity: 0, translateX: -12 }} animate={{ opacity: 1, translateX: 0 }} transition={{ delay: i * 40 }}>
            <View style={s.dayRow}>
              <View style={[s.dayLabel, dc.length > 0 && s.dayLabelActive]}>
                <Text style={[s.dayText, dc.length > 0 && s.dayTextActive]}>{DAYS[day]}</Text>
              </View>
              <View style={s.dayClasses}>
                {dc.length > 0 ? dc.map((cls, ci) => (
                  <View key={cls.id} style={[s.chip, { backgroundColor: `${CLS_COLORS[ci % CLS_COLORS.length]}20`, borderColor: `${CLS_COLORS[ci % CLS_COLORS.length]}40` }]}>
                    <Text style={[s.chipText, { color: CLS_COLORS[ci % CLS_COLORS.length] }]} numberOfLines={1}>{cls.name || 'Unnamed'}{cls.reminder_time ? ` · ${cls.reminder_time}` : ''}</Text>
                  </View>
                )) : <Text style={s.noClass}>No classes</Text>}
              </View>
            </View>
          </MotiView>
        ))}

        {classes.length > 0 && (
          <>
            <Text style={s.sectionTitle}>All Classes</Text>
            {classes.map((cls, i) => (
              <View key={cls.id} style={s.classCard}>
                <View style={[s.colorDot, { backgroundColor: CLS_COLORS[i % CLS_COLORS.length] }]} />
                <View style={{ flex: 1 }}>
                  <Text style={s.className}>{cls.name || 'Unnamed class'}</Text>
                  {cls.teacher && <Text style={s.classTeacher}>{cls.teacher}</Text>}
                  {cls.reminder_days?.length > 0 && (
                    <View style={s.daysRow}>
                      {cls.reminder_days.map(d => (
                        <View key={d} style={s.dayPill}><Text style={s.dayPillText}>{DAYS[d]}</Text></View>
                      ))}
                      {cls.reminder_time && <Text style={s.timeText}>{cls.reminder_time}</Text>}
                    </View>
                  )}
                </View>
                <TouchableOpacity onPress={() => remove.mutate(cls.id)}>
                  <Ionicons name="trash-outline" size={16} color={Colors.dark.foregroundSubtle} />
                </TouchableOpacity>
              </View>
            ))}
          </>
        )}
        <View style={{ height: 100 }} />
      </ScrollView>

      <Modal visible={showModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowModal(false)}>
        <View style={s.modal}>
          <View style={s.modalHeader}>
            <Text style={s.modalTitle}>Add Class</Text>
            <TouchableOpacity onPress={() => setShowModal(false)}><Ionicons name="close" size={24} color={Colors.dark.foregroundMuted} /></TouchableOpacity>
          </View>
          <TextInput style={s.inp} placeholder="Class name *" placeholderTextColor={Colors.dark.foregroundSubtle} value={form.name} onChangeText={t => setForm(f => ({ ...f, name: t }))} />
          <TextInput style={s.inp} placeholder="Teacher name (optional)" placeholderTextColor={Colors.dark.foregroundSubtle} value={form.teacher} onChangeText={t => setForm(f => ({ ...f, teacher: t }))} />
          <Text style={s.dayPickerLabel}>Which days?</Text>
          <View style={s.dayPicker}>
            {DAYS.map((name, d) => (
              <TouchableOpacity key={d} style={[s.dayPickBtn, form.reminder_days.includes(d) && s.dayPickBtnActive]} onPress={() => toggleDay(d)}>
                <Text style={[s.dayPickText, form.reminder_days.includes(d) && s.dayPickTextActive]}>{name.slice(0, 2)}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput style={s.inp} placeholder="Time (e.g. 09:00 AM)" placeholderTextColor={Colors.dark.foregroundSubtle} value={form.reminder_time} onChangeText={t => setForm(f => ({ ...f, reminder_time: t }))} />
          <TouchableOpacity style={s.submitBtn} onPress={submit}>
            <Text style={s.submitText}>Add Class</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 8, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: '700', color: Colors.dark.foreground },
  subtitle: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  addBtn: { width: 40, height: 40, borderRadius: 14, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  content: { paddingHorizontal: 20 },
  dayRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 12 },
  dayLabel: { width: 44, height: 44, borderRadius: 14, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: Colors.dark.cardBorder },
  dayLabelActive: { backgroundColor: `${Colors.primary}20`, borderColor: `${Colors.primary}40` },
  dayText: { fontSize: 12, fontWeight: '600', color: Colors.dark.foregroundMuted },
  dayTextActive: { color: Colors.primary },
  dayClasses: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', gap: 6, paddingTop: 10 },
  chip: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 999, borderWidth: 1 },
  chipText: { fontSize: 12, fontWeight: '600' },
  noClass: { fontSize: 12, color: Colors.dark.foregroundSubtle, paddingTop: 10 },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: Colors.dark.foregroundSubtle, textTransform: 'uppercase', letterSpacing: 1, marginTop: 8, marginBottom: 12 },
  classCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 8 },
  colorDot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  className: { fontSize: 14, fontWeight: '600', color: Colors.dark.foreground },
  classTeacher: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  daysRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginTop: 6 },
  dayPill: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, backgroundColor: `${Colors.primary}20` },
  dayPillText: { fontSize: 10, color: Colors.primary, fontWeight: '600' },
  timeText: { fontSize: 11, color: Colors.dark.foregroundMuted, fontFamily: 'monospace', paddingTop: 3 },
  modal: { flex: 1, backgroundColor: Colors.dark.background, padding: 24 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: Colors.dark.foreground },
  inp: { backgroundColor: Colors.dark.card, borderRadius: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, paddingHorizontal: 16, paddingVertical: 14, fontSize: 14, color: Colors.dark.foreground, marginBottom: 12 },
  dayPickerLabel: { fontSize: 13, color: Colors.dark.foregroundMuted, marginBottom: 8 },
  dayPicker: { flexDirection: 'row', gap: 6, marginBottom: 16 },
  dayPickBtn: { flex: 1, paddingVertical: 8, borderRadius: 10, borderWidth: 1, borderColor: Colors.dark.cardBorder, alignItems: 'center' },
  dayPickBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  dayPickText: { fontSize: 11, color: Colors.dark.foregroundMuted, fontWeight: '600' },
  dayPickTextActive: { color: 'white' },
  submitBtn: { backgroundColor: Colors.primary, borderRadius: 16, paddingVertical: 16, alignItems: 'center', marginTop: 8 },
  submitText: { fontSize: 16, fontWeight: '700', color: 'white' },
});
