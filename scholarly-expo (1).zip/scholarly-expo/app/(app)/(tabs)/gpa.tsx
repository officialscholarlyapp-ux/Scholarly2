import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { useClasses } from '@/hooks/use-data';
import type { Class } from '@/types/database';
import { Colors } from '@/constants/theme';

const gradeToGPA = (pct: number, weighted: boolean) => { const b = pct >= 90 ? 4 : pct >= 80 ? 3 : pct >= 70 ? 2 : pct >= 60 ? 1 : 0; return weighted ? Math.min(5, b + 1) : b; };
const letterGrade = (p: number) => p >= 97 ? 'A+' : p >= 93 ? 'A' : p >= 90 ? 'A-' : p >= 87 ? 'B+' : p >= 83 ? 'B' : p >= 80 ? 'B-' : p >= 77 ? 'C+' : p >= 73 ? 'C' : p >= 70 ? 'C-' : p >= 67 ? 'D+' : p >= 65 ? 'D' : 'F';

export default function GPAScreen() {
  const { data: classes, create, update, remove } = useClasses();
  const withGrades = classes.filter(c => c.current_grade !== null);
  const calcGPA = (w: boolean) => withGrades.length > 0 ? withGrades.reduce((s, c) => s + gradeToGPA(c.current_grade!, w) * (c.credits || 3), 0) / withGrades.reduce((s, c) => s + (c.credits || 3), 0) : null;
  const uw = calcGPA(false); const wt = calcGPA(true);
  const upd = (cls: Class, field: keyof Class, val: unknown) => update.mutate({ id: cls.id, data: { [field]: val } });

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Ionicons name="trending-up" size={24} color={Colors.primary} />
          <View style={{ marginLeft: 10 }}>
            <Text style={styles.title}>GPA Calculator</Text>
            <Text style={styles.subtitle}>Real-time grade tracking</Text>
          </View>
        </View>
        <View style={styles.scoreRow}>
          {[{ label: 'Unweighted GPA', val: uw, max: 4.0, color: Colors.primary }, { label: 'Weighted GPA', val: wt, max: 5.0, color: Colors.accent }].map(s => (
            <View key={s.label} style={styles.scoreCard}>
              <Text style={styles.scoreLabel}>{s.label}</Text>
              <Text style={[styles.scoreVal, { color: s.color }]}>{s.val !== null ? s.val.toFixed(2) : '—'}</Text>
              <Text style={styles.scoreMax}>/ {s.max.toFixed(1)} max</Text>
            </View>
          ))}
        </View>
        <View style={styles.colHeaders}>
          <Text style={[styles.col, { flex: 3 }]}>Class</Text>
          <Text style={[styles.col, { flex: 1.5, textAlign: 'center' }]}>Creds</Text>
          <Text style={[styles.col, { flex: 1.5, textAlign: 'center' }]}>Grade</Text>
          <Text style={[styles.col, { flex: 1.5, textAlign: 'center' }]}>Ltr</Text>
          <Text style={[styles.col, { flex: 1, textAlign: 'center' }]}>AP</Text>
          <View style={{ width: 24 }} />
        </View>
        {classes.map((cls, i) => (
          <MotiView key={cls.id} from={{ opacity: 0, translateX: -12 }} animate={{ opacity: 1, translateX: 0 }} transition={{ delay: i * 40 }}>
            <View style={styles.row}>
              <TextInput style={[styles.inp, { flex: 3 }]} placeholder="Class name" placeholderTextColor={Colors.dark.foregroundSubtle} value={cls.name} onChangeText={t => upd(cls, 'name', t)} onEndEditing={e => update.mutate({ id: cls.id, data: { name: e.nativeEvent.text } })} />
              <TextInput style={[styles.inp, { flex: 1.5, textAlign: 'center' }]} keyboardType="decimal-pad" value={String(cls.credits)} onChangeText={t => upd(cls, 'credits', parseFloat(t) || 3)} />
              <TextInput style={[styles.inp, { flex: 1.5, textAlign: 'center' }]} keyboardType="decimal-pad" placeholder="—" placeholderTextColor={Colors.dark.foregroundSubtle} value={cls.current_grade !== null ? String(cls.current_grade) : ''} onChangeText={t => upd(cls, 'current_grade', t ? parseFloat(t) : null)} />
              <Text style={[styles.letter, { flex: 1.5 }]}>{cls.current_grade !== null ? letterGrade(cls.current_grade) : '—'}</Text>
              <TouchableOpacity style={[styles.check, cls.is_weighted && styles.checkActive]} onPress={() => upd(cls, 'is_weighted', !cls.is_weighted)}>
                {cls.is_weighted && <Ionicons name="checkmark" size={12} color="white" />}
              </TouchableOpacity>
              <TouchableOpacity onPress={() => remove.mutate(cls.id)} style={{ width: 24, alignItems: 'center' }}>
                <Ionicons name="close" size={16} color={Colors.destructive} />
              </TouchableOpacity>
            </View>
          </MotiView>
        ))}
        <TouchableOpacity style={styles.addBtn} onPress={() => create.mutate({ name: '', credits: 3, is_weighted: false, current_grade: null, color: 'bg-primary', reminder_days: [], reminder_time: null, teacher: null })} activeOpacity={0.8}>
          <Ionicons name="add" size={18} color={Colors.dark.foregroundMuted} />
          <Text style={styles.addText}>Add Class</Text>
        </TouchableOpacity>
        <View style={styles.scaleCard}>
          <Text style={styles.scaleTitle}>GPA Scale</Text>
          <View style={styles.scaleRow}>
            {[['A', '90+', '4.0'], ['B', '80+', '3.0'], ['C', '70+', '2.0'], ['D', '60+', '1.0'], ['F', '<60', '0.0']].map(([g, r, p]) => (
              <View key={g} style={styles.scaleItem}>
                <Text style={styles.scaleGrade}>{g}</Text>
                <Text style={styles.scaleRange}>{r}</Text>
                <Text style={styles.scalePoints}>{p}</Text>
              </View>
            ))}
          </View>
        </View>
        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  content: { paddingHorizontal: 20, paddingTop: 8 },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 22, fontWeight: '700', color: Colors.dark.foreground },
  subtitle: { fontSize: 12, color: Colors.dark.foregroundMuted, marginTop: 2 },
  scoreRow: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  scoreCard: { flex: 1, backgroundColor: Colors.dark.card, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  scoreLabel: { fontSize: 11, color: Colors.dark.foregroundMuted, marginBottom: 6 },
  scoreVal: { fontSize: 32, fontWeight: '800', fontFamily: 'monospace' },
  scoreMax: { fontSize: 11, color: Colors.dark.foregroundSubtle, marginTop: 4 },
  colHeaders: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, marginBottom: 6 },
  col: { fontSize: 10, color: Colors.dark.foregroundSubtle, fontWeight: '600', textTransform: 'uppercase' },
  row: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.dark.card, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 8, marginBottom: 6, borderWidth: 1, borderColor: Colors.dark.cardBorder, gap: 4 },
  inp: { fontSize: 13, color: Colors.dark.foreground, paddingVertical: 4 },
  letter: { fontSize: 13, fontFamily: 'monospace', color: Colors.dark.foregroundMuted, textAlign: 'center' },
  check: { width: 20, height: 20, borderRadius: 6, borderWidth: 1.5, borderColor: Colors.dark.cardBorder, alignItems: 'center', justifyContent: 'center' },
  checkActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  addBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderWidth: 1.5, borderStyle: 'dashed', borderColor: Colors.dark.cardBorder, borderRadius: 16, paddingVertical: 14, marginTop: 4, marginBottom: 24 },
  addText: { fontSize: 13, color: Colors.dark.foregroundMuted },
  scaleCard: { backgroundColor: Colors.dark.card, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  scaleTitle: { fontSize: 12, fontWeight: '600', color: Colors.dark.foregroundMuted, marginBottom: 12 },
  scaleRow: { flexDirection: 'row', justifyContent: 'space-between' },
  scaleItem: { alignItems: 'center' },
  scaleGrade: { fontSize: 14, fontWeight: '700', color: Colors.primary },
  scaleRange: { fontSize: 10, color: Colors.dark.foregroundMuted, marginTop: 2 },
  scalePoints: { fontSize: 11, fontFamily: 'monospace', color: Colors.dark.foreground, marginTop: 2 },
});
