import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { MotiView } from 'moti';
import { useAuth } from '@/lib/auth-context';
import { Colors } from '@/constants/theme';

const FREE_FEATURES = ['GPA Calculator', 'Homework Planner', 'Class Schedule', 'Final Grade Calculator', 'Dashboard Overview'];
const PREMIUM_FEATURES = ['Everything in Free', 'Notes → Quiz (AI)', 'Flashcard Generator (AI)', 'Study Guide Generator (AI)', 'Teacher Analyzer (AI)', 'Get an A Strategy (AI)', 'AI Study Planner Chat', 'AI History & Saved Results', 'Priority Support'];

export default function PricingScreen() {
  const { isPremium } = useAuth();

  const handleUpgrade = () => {
    Alert.alert('Coming Soon', 'In-app purchases will be available when the app launches on the App Store. Stay tuned!');
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.topBar}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><Ionicons name="chevron-back" size={24} color={Colors.dark.foreground} /></TouchableOpacity>
        <Text style={s.topTitle}>Upgrade</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false}>
        {isPremium ? (
          <MotiView from={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
            <LinearGradient colors={[Colors.primary, Colors.secondary]} style={s.premiumBanner}>
              <Ionicons name="diamond" size={40} color="white" />
              <Text style={s.premiumBannerTitle}>You're Premium! 🎉</Text>
              <Text style={s.premiumBannerSub}>You have full access to all AI study tools. Keep up the great work!</Text>
            </LinearGradient>
          </MotiView>
        ) : (
          <>
            <MotiView from={{ opacity: 0, translateY: -16 }} animate={{ opacity: 1, translateY: 0 }}>
              <LinearGradient colors={[`${Colors.primary}30`, `${Colors.secondary}20`]} style={s.heroCard}>
                <Ionicons name="diamond-outline" size={36} color={Colors.primary} />
                <Text style={s.heroTitle}>Scholarly Premium</Text>
                <Text style={s.heroSub}>Unlock AI-powered study tools that help you study smarter and get better grades.</Text>
              </LinearGradient>
            </MotiView>

            <View style={s.plansRow}>
              <MotiView from={{ opacity: 0, translateY: 20 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 100 }} style={s.planCardWrap}>
                <View style={s.planCard}>
                  <Text style={s.planName}>Monthly</Text>
                  <Text style={s.planPrice}>$4.99</Text>
                  <Text style={s.planPer}>/month</Text>
                  <TouchableOpacity style={s.planBtn} onPress={handleUpgrade} activeOpacity={0.9}>
                    <Text style={s.planBtnText}>Get Premium</Text>
                  </TouchableOpacity>
                </View>
              </MotiView>
              <MotiView from={{ opacity: 0, translateY: 20 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 160 }} style={s.planCardWrap}>
                <LinearGradient colors={[Colors.primary, Colors.secondary]} style={[s.planCard, s.planCardPop]}>
                  <View style={s.bestValueBadge}><Text style={s.bestValueText}>BEST VALUE</Text></View>
                  <Text style={[s.planName, { color: 'white' }]}>Annual</Text>
                  <Text style={[s.planPrice, { color: 'white' }]}>$29.99</Text>
                  <Text style={[s.planPer, { color: 'rgba(255,255,255,0.7)' }]}>/year · save 50%</Text>
                  <TouchableOpacity style={s.planBtnWhite} onPress={handleUpgrade} activeOpacity={0.9}>
                    <Text style={s.planBtnWhiteText}>Get Premium</Text>
                  </TouchableOpacity>
                </LinearGradient>
              </MotiView>
            </View>
          </>
        )}

        <View style={s.compareSection}>
          <View style={s.compareCol}>
            <Text style={s.compareTitle}>Free</Text>
            {FREE_FEATURES.map((f, i) => (
              <MotiView key={f} from={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 40 }}>
                <View style={s.featureRow}>
                  <Ionicons name="checkmark-circle-outline" size={16} color={Colors.accent} />
                  <Text style={s.featureText}>{f}</Text>
                </View>
              </MotiView>
            ))}
          </View>
          <View style={[s.compareCol, s.premiumCol]}>
            <View style={s.premiumColHeader}>
              <Ionicons name="diamond" size={14} color={Colors.warning} />
              <Text style={[s.compareTitle, { color: Colors.primary }]}>Premium</Text>
            </View>
            {PREMIUM_FEATURES.map((f, i) => (
              <MotiView key={f} from={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 40 }}>
                <View style={s.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={Colors.primary} />
                  <Text style={s.featureText}>{f}</Text>
                </View>
              </MotiView>
            ))}
          </View>
        </View>

        <Text style={s.disclaimer}>Subscriptions auto-renew. Cancel anytime in your App Store or Google Play settings. Prices may vary by region.</Text>
        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground },
  content: { paddingHorizontal: 20 },
  premiumBanner: { borderRadius: 24, padding: 32, alignItems: 'center', gap: 10, marginBottom: 24 },
  premiumBannerTitle: { fontSize: 24, fontWeight: '800', color: 'white' },
  premiumBannerSub: { fontSize: 14, color: 'rgba(255,255,255,0.8)', textAlign: 'center', lineHeight: 20 },
  heroCard: { borderRadius: 20, padding: 24, alignItems: 'center', gap: 10, marginBottom: 20, borderWidth: 1, borderColor: `${Colors.primary}30` },
  heroTitle: { fontSize: 24, fontWeight: '800', color: Colors.dark.foreground },
  heroSub: { fontSize: 13, color: Colors.dark.foregroundMuted, textAlign: 'center', lineHeight: 20, maxWidth: 300 },
  plansRow: { flexDirection: 'row', gap: 12, marginBottom: 28 },
  planCardWrap: { flex: 1 },
  planCard: { backgroundColor: Colors.dark.card, borderRadius: 20, padding: 20, alignItems: 'center', borderWidth: 1, borderColor: Colors.dark.cardBorder, gap: 4 },
  planCardPop: { borderWidth: 0, position: 'relative' },
  bestValueBadge: { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999, marginBottom: 4 },
  bestValueText: { fontSize: 9, fontWeight: '800', color: 'white', letterSpacing: 1 },
  planName: { fontSize: 15, fontWeight: '700', color: Colors.dark.foreground },
  planPrice: { fontSize: 32, fontWeight: '800', color: Colors.primary, letterSpacing: -0.5 },
  planPer: { fontSize: 11, color: Colors.dark.foregroundMuted, marginBottom: 8 },
  planBtn: { width: '100%', paddingVertical: 10, borderRadius: 12, backgroundColor: `${Colors.primary}20`, alignItems: 'center', borderWidth: 1, borderColor: `${Colors.primary}40` },
  planBtnText: { fontSize: 13, fontWeight: '700', color: Colors.primary },
  planBtnWhite: { width: '100%', paddingVertical: 10, borderRadius: 12, backgroundColor: 'white', alignItems: 'center' },
  planBtnWhiteText: { fontSize: 13, fontWeight: '700', color: Colors.primaryDark },
  compareSection: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  compareCol: { flex: 1, backgroundColor: Colors.dark.card, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, gap: 2 },
  premiumCol: { borderColor: `${Colors.primary}40`, backgroundColor: `${Colors.primary}08` },
  premiumColHeader: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 4 },
  compareTitle: { fontSize: 14, fontWeight: '700', color: Colors.dark.foreground, marginBottom: 8 },
  featureRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginBottom: 8 },
  featureText: { flex: 1, fontSize: 12, color: Colors.dark.foreground, lineHeight: 18 },
  disclaimer: { fontSize: 11, color: Colors.dark.foregroundSubtle, textAlign: 'center', lineHeight: 16 },
});
