import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { MotiView } from 'moti';
import { useAIHistory } from '@/hooks/use-data';
import { useAuth } from '@/lib/auth-context';
import { callGeminiJSON } from '@/lib/gemini';
import { Colors } from '@/constants/theme';

interface GetAnAResult {
  current_standing: string;
  week_by_week: { week: string; focus: string; tasks: string[] }[];
  study_techniques: string[];
  common_mistakes: string[];
  exam_day_tips: string[];
  motivation: string;
}

export default function GetAnAScreen() {
  const { isPremium } = useAuth();
  const { save } = useAIHistory();
  const [subject, setSubject] = useState('');
  const [currentGrade, setCurrentGrade] = useState('');
  const [weeksLeft, setWeeksLeft] = useState('');
  const [struggles, setStruggles] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GetAnAResult | null>(null);

  const generate = async () => {
    if (!subject.trim()) return;
    if (!isPremium) { Alert.alert('Premium Required', 'Upgrade to use AI tools.'); return; }
    setLoading(true); setResult(null);
    try {
      const prompt = `Create a detailed "Get an A" game plan for a student.
Subject: ${subject}
Current grade: ${currentGrade || 'unknown'}
Weeks until final exam: ${weeksLeft || 'unknown'}
Main struggles: ${struggles || 'none specified'}

Return JSON with this exact structure:
{
  "current_standing": "honest assessment of where they are",
  "week_by_week": [
    { "week": "Week 1", "focus": "main focus", "tasks": ["task1", "task2", "task3"] },
    { "week": "Week 2", "focus": "main focus", "tasks": ["task1", "task2", "task3"] },
    { "week": "Week 3", "focus": "main focus", "tasks": ["task1", "task2"] },
    { "week": "Final Week", "focus": "exam prep", "tasks": ["task1", "task2", "task3"] }
  ],
  "study_techniques": ["technique1", "technique2", "technique3", "technique4"],
  "common_mistakes": ["mistake1", "mistake2", "mistake3"],
  "exam_day_tips": ["tip1", "tip2", "tip3"],
  "motivation": "short motivational message"
}`;
      const data = await callGeminiJSON<GetAnAResult>(prompt);
      setResult(data);
      await save.mutateAsync({ type: 'get_an_a', title: `Get an A: ${subject}`, input_summary: `${subject} - current: ${currentGrade}`, result: data as any });
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to generate plan.');
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.topBar}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><Ionicons name="chevron-down" size={24} color={Colors.dark.foreground} /></TouchableOpacity>
        <Text style={s.topTitle}>Get an A</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {!result ? (
          <>
            <LinearGradient colors={[`${Colors.secondary}30`, `${Colors.primary}20`]} style={s.heroCard}>
              <Ionicons name="school" size={32} color={Colors.secondary} />
              <Text style={s.heroTitle}>Your personalized A game plan</Text>
              <Text style={s.heroSub}>Tell us about your class and we'll build you a step-by-step strategy.</Text>
            </LinearGradient>
            <TextInput style={s.inp} placeholder="Subject / Course name *" placeholderTextColor={Colors.dark.foregroundSubtle} value={subject} onChangeText={setSubject} />
            <View style={s.row2}>
              <TextInput style={[s.inp, { flex: 1 }]} placeholder="Current grade (e.g. 72%)" placeholderTextColor={Colors.dark.foregroundSubtle} value={currentGrade} onChangeText={setCurrentGrade} keyboardType="decimal-pad" />
              <TextInput style={[s.inp, { flex: 1 }]} placeholder="Weeks until exam" placeholderTextColor={Colors.dark.foregroundSubtle} value={weeksLeft} onChangeText={setWeeksLeft} keyboardType="number-pad" />
            </View>
            <TextInput style={[s.inp, s.bigInp]} placeholder="What are you struggling with? (optional)" placeholderTextColor={Colors.dark.foregroundSubtle} value={struggles} onChangeText={setStruggles} multiline textAlignVertical="top" />
            <TouchableOpacity style={[s.genBtn, !subject.trim() && s.genBtnOff]} onPress={generate} disabled={loading || !subject.trim()}>
              {loading ? <ActivityIndicator color="white" /> : <><Ionicons name="sparkles" size={18} color="white" /><Text style={s.genBtnText}>Build My A Plan</Text></>}
            </TouchableOpacity>
          </>
        ) : (
          <MotiView from={{ opacity: 0, translateY: 16 }} animate={{ opacity: 1, translateY: 0 }}>
            <View style={s.resultHeader}>
              <Text style={s.resultTitle}>Your A Plan: {subject}</Text>
              <TouchableOpacity style={s.resetBtn} onPress={() => setResult(null)}>
                <Ionicons name="refresh-outline" size={16} color={Colors.primary} />
                <Text style={s.resetText}>New</Text>
              </TouchableOpacity>
            </View>
            <View style={s.card}>
              <Text style={s.cardTitle}>📊 Current Standing</Text>
              <Text style={s.cardText}>{result.current_standing}</Text>
            </View>
            <Text style={s.sectionTitle}>Week by Week Plan</Text>
            {result.week_by_week?.map((week, i) => (
              <View key={i} style={s.weekCard}>
                <View style={s.weekHeader}>
                  <View style={s.weekBadge}><Text style={s.weekBadgeText}>{week.week}</Text></View>
                  <Text style={s.weekFocus}>{week.focus}</Text>
                </View>
                {week.tasks?.map((task, j) => (
                  <View key={j} style={s.task}><View style={s.taskDot} /><Text style={s.taskText}>{task}</Text></View>
                ))}
              </View>
            ))}
            <View style={[s.card, s.greenCard]}>
              <Text style={[s.cardTitle, { color: Colors.accent }]}>🧠 Study Techniques</Text>
              {result.study_techniques?.map((t, i) => <View key={i} style={s.listItem}><View style={[s.bullet, { backgroundColor: Colors.accent }]} /><Text style={s.listText}>{t}</Text></View>)}
            </View>
            <View style={[s.card, s.redCard]}>
              <Text style={[s.cardTitle, { color: Colors.destructive }]}>❌ Common Mistakes to Avoid</Text>
              {result.common_mistakes?.map((m, i) => <View key={i} style={s.listItem}><View style={[s.bullet, { backgroundColor: Colors.destructive }]} /><Text style={s.listText}>{m}</Text></View>)}
            </View>
            <View style={s.card}>
              <Text style={s.cardTitle}>🎯 Exam Day Tips</Text>
              {result.exam_day_tips?.map((t, i) => <View key={i} style={s.listItem}><View style={s.bullet} /><Text style={s.listText}>{t}</Text></View>)}
            </View>
            <LinearGradient colors={[Colors.primary, Colors.secondary]} style={s.motivCard}>
              <Ionicons name="flame" size={24} color="white" />
              <Text style={s.motivText}>{result.motivation}</Text>
            </LinearGradient>
          </MotiView>
        )}
        <View style={{ height: 60 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground },
  content: { paddingHorizontal: 20 },
  heroCard: { borderRadius: 20, padding: 20, alignItems: 'center', gap: 8, marginBottom: 20 },
  heroTitle: { fontSize: 18, fontWeight: '700', color: Colors.dark.foreground, textAlign: 'center' },
  heroSub: { fontSize: 13, color: Colors.dark.foregroundMuted, textAlign: 'center', lineHeight: 18 },
  inp: { backgroundColor: Colors.dark.card, borderRadius: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, paddingHorizontal: 16, paddingVertical: 14, fontSize: 14, color: Colors.dark.foreground, marginBottom: 12 },
  row2: { flexDirection: 'row', gap: 10 },
  bigInp: { height: 120, paddingTop: 14 },
  genBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: Colors.primary, borderRadius: 18, paddingVertical: 18 },
  genBtnOff: { opacity: 0.5 },
  genBtnText: { fontSize: 16, fontWeight: '700', color: 'white' },
  resultHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  resultTitle: { fontSize: 18, fontWeight: '700', color: Colors.dark.foreground },
  resetBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  resetText: { fontSize: 13, color: Colors.primary, fontWeight: '600' },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: Colors.dark.foregroundSubtle, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10, marginTop: 4 },
  card: { backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 12 },
  redCard: { borderColor: `${Colors.destructive}30`, backgroundColor: `${Colors.destructive}08` },
  greenCard: { borderColor: `${Colors.accent}30`, backgroundColor: `${Colors.accent}08` },
  cardTitle: { fontSize: 14, fontWeight: '700', color: Colors.dark.foreground, marginBottom: 10 },
  cardText: { fontSize: 13, color: Colors.dark.foreground, lineHeight: 20 },
  weekCard: { backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 10 },
  weekHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  weekBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, backgroundColor: `${Colors.primary}25` },
  weekBadgeText: { fontSize: 11, fontWeight: '700', color: Colors.primary },
  weekFocus: { flex: 1, fontSize: 13, fontWeight: '600', color: Colors.dark.foreground },
  task: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 6 },
  taskDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.primary, marginTop: 7 },
  taskText: { flex: 1, fontSize: 13, color: Colors.dark.foreground, lineHeight: 19 },
  listItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 6 },
  bullet: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.primary, marginTop: 7 },
  listText: { flex: 1, fontSize: 13, color: Colors.dark.foreground, lineHeight: 20 },
  motivCard: { borderRadius: 20, padding: 20, flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 4 },
  motivText: { flex: 1, fontSize: 14, color: 'white', fontWeight: '600', lineHeight: 21 },
});
