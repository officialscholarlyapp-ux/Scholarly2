import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { useAIHistory } from '@/hooks/use-data';
import { useAuth } from '@/lib/auth-context';
import { callGeminiJSON } from '@/lib/gemini';
import { Colors } from '@/constants/theme';

interface TeacherAnalysis {
  teaching_style: string;
  exam_style: string;
  what_they_value: string[];
  red_flags: string[];
  winning_strategies: string[];
  grade_boosters: string[];
  overall_tip: string;
}

export default function TeacherAnalyzerScreen() {
  const { isPremium } = useAuth();
  const { save } = useAIHistory();
  const [teacherName, setTeacherName] = useState('');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TeacherAnalysis | null>(null);

  const analyze = async () => {
    if (!description.trim()) return;
    if (!isPremium) { Alert.alert('Premium Required', 'Upgrade to use AI tools.'); return; }
    setLoading(true); setResult(null);
    try {
      const prompt = `Analyze this teacher/professor and give strategic academic advice for a student.
Teacher: ${teacherName || 'Unknown'}
Subject: ${subject || 'Unknown'}
Student's description: ${description}

Return JSON with this exact structure:
{
  "teaching_style": "brief description of how they teach",
  "exam_style": "how they likely test students",
  "what_they_value": ["thing1", "thing2", "thing3"],
  "red_flags": ["warning1", "warning2"],
  "winning_strategies": ["strategy1", "strategy2", "strategy3", "strategy4"],
  "grade_boosters": ["tip1", "tip2", "tip3"],
  "overall_tip": "single most important piece of advice"
}`;
      const data = await callGeminiJSON<TeacherAnalysis>(prompt);
      setResult(data);
      await save.mutateAsync({ type: 'teacher_analyzer', title: `${teacherName || 'Teacher'} - ${subject || 'Analysis'}`, input_summary: description.slice(0, 100), result: data as any });
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Analysis failed. Please try again.');
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.topBar}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><Ionicons name="chevron-down" size={24} color={Colors.dark.foreground} /></TouchableOpacity>
        <Text style={s.topTitle}>Teacher Analyzer</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {!result ? (
          <>
            <View style={s.infoCard}>
              <Ionicons name="information-circle-outline" size={20} color={Colors.primary} />
              <Text style={s.infoText}>Describe your teacher's style, grading habits, what they emphasize — the more detail, the better the strategy.</Text>
            </View>
            <TextInput style={s.inp} placeholder="Teacher/Professor name (optional)" placeholderTextColor={Colors.dark.foregroundSubtle} value={teacherName} onChangeText={setTeacherName} />
            <TextInput style={s.inp} placeholder="Subject / Course (optional)" placeholderTextColor={Colors.dark.foregroundSubtle} value={subject} onChangeText={setSubject} />
            <TextInput style={[s.inp, s.bigInp]} placeholder="Describe your teacher... How do they grade? What do they focus on? Any quirks? What do classmates say?" placeholderTextColor={Colors.dark.foregroundSubtle} value={description} onChangeText={setDescription} multiline textAlignVertical="top" />
            <TouchableOpacity style={[s.analyzeBtn, !description.trim() && s.analyzeBtnOff]} onPress={analyze} disabled={loading || !description.trim()}>
              {loading ? <ActivityIndicator color="white" /> : <><Ionicons name="sparkles" size={18} color="white" /><Text style={s.analyzeBtnText}>Analyze Teacher</Text></>}
            </TouchableOpacity>
          </>
        ) : (
          <MotiView from={{ opacity: 0, translateY: 16 }} animate={{ opacity: 1, translateY: 0 }}>
            <View style={s.resultHeader}>
              <Text style={s.resultTitle}>Analysis: {teacherName || 'Your Teacher'}</Text>
              <TouchableOpacity style={s.resetBtn} onPress={() => setResult(null)}>
                <Ionicons name="refresh-outline" size={16} color={Colors.primary} />
                <Text style={s.resetText}>New</Text>
              </TouchableOpacity>
            </View>

            <View style={s.card}>
              <Text style={s.cardTitle}>📖 Teaching Style</Text>
              <Text style={s.cardText}>{result.teaching_style}</Text>
            </View>
            <View style={s.card}>
              <Text style={s.cardTitle}>📝 Exam Style</Text>
              <Text style={s.cardText}>{result.exam_style}</Text>
            </View>
            <View style={s.card}>
              <Text style={s.cardTitle}>⭐ What They Value</Text>
              {result.what_they_value?.map((v, i) => <View key={i} style={s.listItem}><View style={s.bullet} /><Text style={s.listText}>{v}</Text></View>)}
            </View>
            <View style={[s.card, s.redCard]}>
              <Text style={[s.cardTitle, { color: Colors.destructive }]}>⚠️ Red Flags</Text>
              {result.red_flags?.map((v, i) => <View key={i} style={s.listItem}><View style={[s.bullet, { backgroundColor: Colors.destructive }]} /><Text style={s.listText}>{v}</Text></View>)}
            </View>
            <View style={[s.card, s.greenCard]}>
              <Text style={[s.cardTitle, { color: Colors.accent }]}>🎯 Winning Strategies</Text>
              {result.winning_strategies?.map((v, i) => <View key={i} style={s.listItem}><View style={[s.bullet, { backgroundColor: Colors.accent }]} /><Text style={s.listText}>{v}</Text></View>)}
            </View>
            <View style={s.card}>
              <Text style={s.cardTitle}>🚀 Grade Boosters</Text>
              {result.grade_boosters?.map((v, i) => <View key={i} style={s.listItem}><View style={[s.bullet, { backgroundColor: Colors.primary }]} /><Text style={s.listText}>{v}</Text></View>)}
            </View>
            <View style={[s.card, s.tipCard]}>
              <Text style={s.tipLabel}>💡 Most Important Tip</Text>
              <Text style={s.tipText}>{result.overall_tip}</Text>
            </View>
          </MotiView>
        )}
        <View style={{ height: 60 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground },
  content: { paddingHorizontal: 20 },
  infoCard: { flexDirection: 'row', gap: 10, backgroundColor: `${Colors.primary}15`, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: `${Colors.primary}30`, marginBottom: 16 },
  infoText: { flex: 1, fontSize: 13, color: Colors.dark.foregroundMuted, lineHeight: 18 },
  inp: { backgroundColor: Colors.dark.card, borderRadius: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, paddingHorizontal: 16, paddingVertical: 14, fontSize: 14, color: Colors.dark.foreground, marginBottom: 12 },
  bigInp: { height: 180, paddingTop: 14 },
  analyzeBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: Colors.primary, borderRadius: 18, paddingVertical: 18 },
  analyzeBtnOff: { opacity: 0.5 },
  analyzeBtnText: { fontSize: 16, fontWeight: '700', color: 'white' },
  resultHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  resultTitle: { fontSize: 18, fontWeight: '700', color: Colors.dark.foreground },
  resetBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  resetText: { fontSize: 13, color: Colors.primary, fontWeight: '600' },
  card: { backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 12 },
  redCard: { borderColor: `${Colors.destructive}30`, backgroundColor: `${Colors.destructive}08` },
  greenCard: { borderColor: `${Colors.accent}30`, backgroundColor: `${Colors.accent}08` },
  tipCard: { borderColor: `${Colors.primary}40`, backgroundColor: `${Colors.primary}10` },
  cardTitle: { fontSize: 14, fontWeight: '700', color: Colors.dark.foreground, marginBottom: 10 },
  cardText: { fontSize: 13, color: Colors.dark.foreground, lineHeight: 20 },
  listItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 6 },
  bullet: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.primary, marginTop: 7 },
  listText: { flex: 1, fontSize: 13, color: Colors.dark.foreground, lineHeight: 20 },
  tipLabel: { fontSize: 12, fontWeight: '700', color: Colors.primary, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 },
  tipText: { fontSize: 14, color: Colors.dark.foreground, lineHeight: 22, fontWeight: '500' },
});
