import { useEffect } from 'react';
import { Stack, router } from 'expo-router';
import { useAuth } from '@/lib/auth-context';
import { View, ActivityIndicator } from 'react-native';
import { Colors } from '@/constants/theme';

export default function AppLayout() {
  const { isAuthenticated, isLoading } = useAuth();
  useEffect(() => { if (!isLoading && !isAuthenticated) router.replace('/(auth)/splash'); }, [isAuthenticated, isLoading]);
  if (isLoading) return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.dark.background }}><ActivityIndicator color={Colors.primary} size="large" /></View>;
  if (!isAuthenticated) return null;
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="quiz-maker/index" options={{ presentation: 'modal' }} />
      <Stack.Screen name="study-planner/index" options={{ presentation: 'modal' }} />
      <Stack.Screen name="teacher-analyzer/index" options={{ presentation: 'modal' }} />
      <Stack.Screen name="get-an-a/index" options={{ presentation: 'modal' }} />
      <Stack.Screen name="history/index" />
      <Stack.Screen name="pricing/index" />
      <Stack.Screen name="final-grade/index" />
    </Stack>
  );
}
