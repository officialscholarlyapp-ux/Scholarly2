import React, { useState, useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { MotiView } from 'moti';
import { useStudyConversations } from '@/hooks/use-data';
import { callGemini } from '@/lib/gemini';
import { useAuth } from '@/lib/auth-context';
import type { ChatMessage, StudyConversation } from '@/types/database';
import { Colors } from '@/constants/theme';

export default function StudyPlannerScreen() {
  const { isPremium } = useAuth();
  const { data: conversations, create, updateMessages, remove } = useStudyConversations();
  const [active, setActive] = useState<StudyConversation | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<ScrollView>(null);

  const startNew = async () => {
    const conv = await create.mutateAsync();
    setActive(conv);
    const welcome: ChatMessage = { role: 'assistant', content: "Hi! I'm your AI study planner. Tell me what you're studying, when your exam is, and how much time you have — I'll build you a personalized study plan. 📚" };
    setMessages([welcome]);
  };

  const openConv = (conv: StudyConversation) => {
    setActive(conv);
    setMessages((conv.messages as ChatMessage[]) ?? []);
  };

  const send = async () => {
    if (!input.trim() || loading || !active) return;
    const userMsg: ChatMessage = { role: 'user', content: input.trim() };
    const updated = [...messages, userMsg];
    setMessages(updated);
    setInput('');
    setLoading(true);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    try {
      const history = updated.map(m => `${m.role === 'user' ? 'Student' : 'Study Planner'}: ${m.content}`).join('\n');
      const prompt = `You are an expert AI study planner helping a student. Be concise, practical, and encouraging.\n\nConversation so far:\n${history}\n\nRespond as the Study Planner:`;
      const reply = await callGemini(prompt);
      const aiMsg: ChatMessage = { role: 'assistant', content: reply };
      const final = [...updated, aiMsg];
      setMessages(final);
      await updateMessages.mutateAsync({ id: active.id, messages: final });
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    } catch { } finally { setLoading(false); }
  };

  if (active) {
    return (
      <SafeAreaView style={s.safe} edges={['top', 'bottom']}>
        <View style={s.topBar}>
          <TouchableOpacity style={s.backBtn} onPress={() => { setActive(null); setMessages([]); }}>
            <Ionicons name="chevron-down" size={24} color={Colors.dark.foreground} />
          </TouchableOpacity>
          <Text style={s.topTitle} numberOfLines={1}>{active.title}</Text>
          <TouchableOpacity onPress={() => { remove.mutate(active.id); setActive(null); setMessages([]); }}>
            <Ionicons name="trash-outline" size={18} color={Colors.destructive} />
          </TouchableOpacity>
        </View>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }} keyboardVerticalOffset={0}>
          <ScrollView ref={scrollRef} contentContainerStyle={s.chat} showsVerticalScrollIndicator={false}>
            {messages.map((msg, i) => (
              <MotiView key={i} from={{ opacity: 0, translateY: 8 }} animate={{ opacity: 1, translateY: 0 }} transition={{ delay: 50 }}>
                <View style={[s.bubble, msg.role === 'user' ? s.userBubble : s.aiBubble]}>
                  {msg.role === 'assistant' && <View style={s.aiAvatar}><Ionicons name="sparkles" size={14} color={Colors.primary} /></View>}
                  <View style={[s.bubbleInner, msg.role === 'user' ? s.userBubbleInner : s.aiBubbleInner]}>
                    <Text style={[s.bubbleText, msg.role === 'user' && s.userBubbleText]}>{msg.content}</Text>
                  </View>
                </View>
              </MotiView>
            ))}
            {loading && (
              <View style={[s.bubble, s.aiBubble]}>
                <View style={s.aiAvatar}><Ionicons name="sparkles" size={14} color={Colors.primary} /></View>
                <View style={s.aiBubbleInner}><ActivityIndicator size="small" color={Colors.primary} /></View>
              </View>
            )}
            <View style={{ height: 20 }} />
          </ScrollView>
          <View style={s.inputRow}>
            <TextInput style={s.chatInput} placeholder="Ask your study planner..." placeholderTextColor={Colors.dark.foregroundSubtle} value={input} onChangeText={setInput} multiline returnKeyType="send" onSubmitEditing={send} />
            <TouchableOpacity style={[s.sendBtn, !input.trim() && s.sendBtnOff]} onPress={send} disabled={!input.trim() || loading}>
              <Ionicons name="send" size={18} color="white" />
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.topBar}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><Ionicons name="chevron-down" size={24} color={Colors.dark.foreground} /></TouchableOpacity>
        <Text style={s.topTitle}>Study Planner</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={s.content}>
        <TouchableOpacity style={s.newBtn} onPress={startNew} activeOpacity={0.9}>
          <Ionicons name="add" size={20} color="white" />
          <Text style={s.newBtnText}>New Study Plan</Text>
        </TouchableOpacity>
        {conversations.length > 0 && (
          <>
            <Text style={s.sectionTitle}>Past Plans</Text>
            {conversations.map((conv, i) => (
              <MotiView key={conv.id} from={{ opacity: 0, translateX: -12 }} animate={{ opacity: 1, translateX: 0 }} transition={{ delay: i * 40 }}>
                <TouchableOpacity style={s.convCard} onPress={() => openConv(conv)} activeOpacity={0.85}>
                  <View style={s.convIcon}><Ionicons name="calendar-outline" size={20} color={Colors.primary} /></View>
                  <View style={{ flex: 1 }}>
                    <Text style={s.convTitle} numberOfLines={1}>{conv.title}</Text>
                    <Text style={s.convDate}>{new Date(conv.updated_at).toLocaleDateString()}</Text>
                  </View>
                  <TouchableOpacity onPress={() => remove.mutate(conv.id)}><Ionicons name="trash-outline" size={16} color={Colors.dark.foregroundSubtle} /></TouchableOpacity>
                </TouchableOpacity>
              </MotiView>
            ))}
          </>
        )}
        {conversations.length === 0 && (
          <View style={s.empty}>
            <Ionicons name="calendar-outline" size={48} color={Colors.dark.foregroundSubtle} />
            <Text style={s.emptyTitle}>No study plans yet</Text>
            <Text style={s.emptySub}>Tap "New Study Plan" to get started with your AI study assistant.</Text>
          </View>
        )}
        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground, flex: 1, textAlign: 'center', marginHorizontal: 8 },
  content: { paddingHorizontal: 20 },
  newBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: Colors.primary, borderRadius: 18, paddingVertical: 16, marginBottom: 24 },
  newBtnText: { fontSize: 16, fontWeight: '700', color: 'white' },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: Colors.dark.foregroundSubtle, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 },
  convCard: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 8 },
  convIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: `${Colors.primary}20`, alignItems: 'center', justifyContent: 'center' },
  convTitle: { fontSize: 14, fontWeight: '600', color: Colors.dark.foreground },
  convDate: { fontSize: 11, color: Colors.dark.foregroundMuted, marginTop: 2 },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground },
  emptySub: { fontSize: 13, color: Colors.dark.foregroundMuted, textAlign: 'center', maxWidth: 280, lineHeight: 20 },
  chat: { paddingHorizontal: 16, paddingTop: 12 },
  bubble: { flexDirection: 'row', marginBottom: 12, alignItems: 'flex-end', gap: 8 },
  userBubble: { justifyContent: 'flex-end' },
  aiBubble: { justifyContent: 'flex-start' },
  aiAvatar: { width: 28, height: 28, borderRadius: 10, backgroundColor: `${Colors.primary}20`, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  bubbleInner: { maxWidth: '80%', borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10 },
  userBubbleInner: { backgroundColor: Colors.primary, borderBottomRightRadius: 4 },
  aiBubbleInner: { backgroundColor: Colors.dark.card, borderWidth: 1, borderColor: Colors.dark.cardBorder, borderBottomLeftRadius: 4 },
  bubbleText: { fontSize: 14, color: Colors.dark.foreground, lineHeight: 20 },
  userBubbleText: { color: 'white' },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 10, paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: 1, borderTopColor: Colors.dark.cardBorder, backgroundColor: Colors.dark.background },
  chatInput: { flex: 1, backgroundColor: Colors.dark.card, borderRadius: 20, borderWidth: 1, borderColor: Colors.dark.cardBorder, paddingHorizontal: 16, paddingVertical: 10, fontSize: 14, color: Colors.dark.foreground, maxHeight: 100 },
  sendBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center' },
  sendBtnOff: { opacity: 0.5 },
});
