import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Image } from 'expo-image';
import { MotiView } from 'moti';
import { useAIHistory } from '@/hooks/use-data';
import { useAuth } from '@/lib/auth-context';
import { callGeminiJSON } from '@/lib/gemini';
import { Colors } from '@/constants/theme';

const TYPES = [
  { id: 'quiz', label: 'Practice Quiz', icon: 'flask-outline' as const, desc: 'Multiple choice' },
  { id: 'flashcards', label: 'Flashcards', icon: 'duplicate-outline' as const, desc: 'Term & definition' },
  { id: 'summary', label: 'Summary', icon: 'document-text-outline' as const, desc: 'Key points' },
  { id: 'study_guide', label: 'Study Guide', icon: 'list-outline' as const, desc: 'Structured review' },
] as const;
type OType = typeof TYPES[number]['id'];

export default function QuizMakerScreen() {
  const { isPremium } = useAuth();
  const { save } = useAIHistory();
  const [notes, setNotes] = useState('');
  const [subject, setSubject] = useState('');
  const [oType, setOType] = useState<OType>('quiz');
  const [qCount, setQCount] = useState(5);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [activeQ, setActiveQ] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});

  const pickImage = async () => {
    const { granted } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!granted) { Alert.alert('Permission needed', 'Please allow photo access.'); return; }
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7 });
    if (!res.canceled) setImageUri(res.assets[0].uri);
  };

  const generate = async () => {
    if (!notes.trim() && !imageUri) return;
    if (!isPremium) { Alert.alert('Premium Required', 'Upgrade to Scholarly Premium to use AI tools.'); return; }
    setLoading(true); setResult(null);
    try {
      const sub = subject || 'General';
      let prompt = '';
      if (oType === 'quiz') prompt = `Generate exactly ${qCount} multiple-choice quiz questions about: ${sub}.\nNotes: ${notes}\nReturn JSON: { "questions": [{ "question": "...", "options": ["A) ...", "B) ...", "C) ...", "D) ..."], "answer": "A) ...", "explanation": "..." }] }`;
      else if (oType === 'flashcards') prompt = `Generate 10 flashcards from these notes. Subject: ${sub}.\nNotes: ${notes}\nReturn JSON: { "flashcards": [{ "term": "...", "definition": "..." }] }`;
      else if (oType === 'summary') prompt = `Summarize these notes into key bullet points. Subject: ${sub}.\nNotes: ${notes}\nReturn JSON: { "summary": "• point1\\n• point2\\n..." }`;
      else prompt = `Create a structured study guide. Subject: ${sub}.\nNotes: ${notes}\nReturn JSON: { "study_guide": "formatted study guide text here" }`;
      const data = await callGeminiJSON<any>(prompt);
      setResult({ type: oType, ...data });
      setAnswers({});
      await save.mutateAsync({ type: oType as any, title: `${sub} ${oType.replace('_', ' ')}`, input_summary: notes.slice(0, 100), result: data });
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Generation failed. Please try again.');
    } finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <View style={s.topBar}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><Ionicons name="chevron-down" size={24} color={Colors.dark.foreground} /></TouchableOpacity>
        <Text style={s.topTitle}>Notes → Quiz</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {!result ? (
          <>
            <View style={s.typeGrid}>
              {TYPES.map(t => (
                <TouchableOpacity key={t.id} style={[s.typeBtn, oType === t.id && s.typeBtnActive]} onPress={() => setOType(t.id)}>
                  <Ionicons name={t.icon} size={20} color={oType === t.id ? Colors.primary : Colors.dark.foregroundMuted} />
                  <Text style={[s.typeLabel, oType === t.id && s.typeLabelActive]}>{t.label}</Text>
                  <Text style={s.typeDesc}>{t.desc}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput style={s.inp} placeholder="Subject (optional)" placeholderTextColor={Colors.dark.foregroundSubtle} value={subject} onChangeText={setSubject} />
            <TextInput style={[s.inp, s.notesInp]} placeholder="Paste your notes here..." placeholderTextColor={Colors.dark.foregroundSubtle} value={notes} onChangeText={setNotes} multiline textAlignVertical="top" />
            <TouchableOpacity style={s.imgBtn} onPress={pickImage}>
              <Ionicons name="image-outline" size={18} color={Colors.dark.foregroundMuted} />
              <Text style={s.imgBtnText}>{imageUri ? 'Change image' : 'Add image of notes'}</Text>
            </TouchableOpacity>
            {imageUri && (
              <View style={s.imgPreviewRow}>
                <Image source={{ uri: imageUri }} style={s.imgPreview} />
                <TouchableOpacity onPress={() => setImageUri(null)}><Ionicons name="close-circle" size={22} color={Colors.destructive} /></TouchableOpacity>
              </View>
            )}
            {oType === 'quiz' && (
              <View style={s.countRow}>
                <Text style={s.countLabel}>Number of questions: {qCount}</Text>
                <View style={s.countBtns}>
                  {[5, 10, 15, 20].map(n => (
                    <TouchableOpacity key={n} style={[s.countBtn, qCount === n && s.countBtnActive]} onPress={() => setQCount(n)}>
                      <Text style={[s.countBtnText, qCount === n && s.countBtnTextActive]}>{n}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}
            <TouchableOpacity style={[s.genBtn, (!notes.trim() && !imageUri) && s.genBtnOff]} onPress={generate} disabled={loading || (!notes.trim() && !imageUri)}>
              {loading ? <ActivityIndicator color="white" /> : <><Ionicons name="sparkles" size={18} color="white" /><Text style={s.genBtnText}>Generate {oType.replace('_', ' ')}</Text></>}
            </TouchableOpacity>
          </>
        ) : (
          <MotiView from={{ opacity: 0, translateY: 16 }} animate={{ opacity: 1, translateY: 0 }}>
            <View style={s.resultHeader}>
              <Text style={s.resultTitle}>Your {result.type.replace('_', ' ')}</Text>
              <TouchableOpacity style={s.resetBtn} onPress={() => setResult(null)}>
                <Ionicons name="refresh-outline" size={16} color={Colors.primary} />
                <Text style={s.resetText}>New</Text>
              </TouchableOpacity>
            </View>
            {result.questions?.map((q: any, i: number) => (
              <TouchableOpacity key={i} style={s.qCard} onPress={() => setActiveQ(activeQ === i ? null : i)} activeOpacity={0.9}>
                <Text style={s.qNum}>Q{i + 1}</Text>
                <Text style={s.qText}>{q.question}</Text>
                {q.options.map((opt: string) => {
                  const sel = answers[i] === opt;
                  const correct = activeQ === i && opt === q.answer;
                  const wrong = activeQ === i && sel && opt !== q.answer;
                  return (
                    <TouchableOpacity key={opt} style={[s.opt, correct && s.optCorrect, wrong && s.optWrong, sel && !correct && !wrong && s.optSel]}
                      onPress={() => setAnswers(prev => ({ ...prev, [i]: opt }))}>
                      <Text style={[s.optText, (correct || wrong) && { fontWeight: '700' }]}>{opt}</Text>
                    </TouchableOpacity>
                  );
                })}
                {activeQ === i && q.explanation && <View style={s.explain}><Text style={s.explainText}>💡 {q.explanation}</Text></View>}
              </TouchableOpacity>
            ))}
            {result.flashcards?.map((f: any, i: number) => (
              <View key={i} style={s.flashcard}>
                <Text style={s.flashTerm}>{f.term}</Text>
                <Text style={s.flashDef}>{f.definition}</Text>
              </View>
            ))}
            {(result.summary || result.study_guide) && (
              <View style={s.textResult}><Text style={s.textResultContent}>{result.summary || result.study_guide}</Text></View>
            )}
          </MotiView>
        )}
        <View style={{ height: 60 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.dark.background },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.dark.card, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 17, fontWeight: '700', color: Colors.dark.foreground },
  content: { paddingHorizontal: 20 },
  typeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 },
  typeBtn: { flex: 1, minWidth: '45%', backgroundColor: Colors.dark.card, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, alignItems: 'center', gap: 4 },
  typeBtnActive: { borderColor: Colors.primary, backgroundColor: `${Colors.primary}15` },
  typeLabel: { fontSize: 13, fontWeight: '600', color: Colors.dark.foregroundMuted },
  typeLabelActive: { color: Colors.primary },
  typeDesc: { fontSize: 10, color: Colors.dark.foregroundSubtle },
  inp: { backgroundColor: Colors.dark.card, borderRadius: 14, borderWidth: 1, borderColor: Colors.dark.cardBorder, paddingHorizontal: 16, paddingVertical: 14, fontSize: 14, color: Colors.dark.foreground, marginBottom: 12 },
  notesInp: { height: 160, paddingTop: 14 },
  imgBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1, borderColor: Colors.dark.cardBorder, alignSelf: 'flex-start', marginBottom: 12 },
  imgBtnText: { fontSize: 13, color: Colors.dark.foregroundMuted },
  imgPreviewRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  imgPreview: { width: 64, height: 64, borderRadius: 10 },
  countRow: { marginBottom: 20 },
  countLabel: { fontSize: 13, color: Colors.dark.foregroundMuted, marginBottom: 8 },
  countBtns: { flexDirection: 'row', gap: 8 },
  countBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  countBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  countBtnText: { fontSize: 13, color: Colors.dark.foregroundMuted, fontWeight: '600' },
  countBtnTextActive: { color: 'white' },
  genBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: Colors.primary, borderRadius: 18, paddingVertical: 18 },
  genBtnOff: { opacity: 0.5 },
  genBtnText: { fontSize: 16, fontWeight: '700', color: 'white' },
  resultHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  resultTitle: { fontSize: 18, fontWeight: '700', color: Colors.dark.foreground, textTransform: 'capitalize' },
  resetBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  resetText: { fontSize: 13, color: Colors.primary, fontWeight: '600' },
  qCard: { backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 12 },
  qNum: { fontSize: 10, color: Colors.primary, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  qText: { fontSize: 14, fontWeight: '600', color: Colors.dark.foreground, marginBottom: 12, lineHeight: 20 },
  opt: { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 6 },
  optSel: { borderColor: Colors.primary, backgroundColor: `${Colors.primary}10` },
  optCorrect: { borderColor: Colors.accent, backgroundColor: `${Colors.accent}15` },
  optWrong: { borderColor: Colors.destructive, backgroundColor: `${Colors.destructive}10` },
  optText: { fontSize: 13, color: Colors.dark.foreground },
  explain: { marginTop: 8, padding: 12, backgroundColor: `${Colors.accent}10`, borderRadius: 10 },
  explainText: { fontSize: 12, color: Colors.accent, lineHeight: 18 },
  flashcard: { backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder, marginBottom: 8 },
  flashTerm: { fontSize: 14, fontWeight: '700', color: Colors.primary, marginBottom: 6 },
  flashDef: { fontSize: 13, color: Colors.dark.foreground, lineHeight: 20 },
  textResult: { backgroundColor: Colors.dark.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: Colors.dark.cardBorder },
  textResultContent: { fontSize: 13, color: Colors.dark.foreground, lineHeight: 22 },
});
