# Scholarly — Expo React Native App

Full student productivity app built with Expo SDK 51, TypeScript, Supabase, and Gemini AI.

---

## What's included

| Screen | Description |
|---|---|
| Splash / Login | Email, Google, Apple sign-in |
| Dashboard | GPA overview, pending homework, quick actions |
| GPA Calculator | Live grade tracking with weighted/unweighted GPA |
| Homework Planner | Add, filter, and complete assignments |
| Class Schedule | Weekly view with per-day class layout |
| Final Grade Calc | Simple and weighted grade calculator |
| Notes → Quiz | AI quiz/flashcard/summary generator (Gemini) |
| Study Planner | AI chat-based study session planner (Gemini) |
| Teacher Analyzer | AI strategy based on professor description (Gemini) |
| Get an A | Personalized week-by-week A plan (Gemini) |
| AI History | Browse and review all past AI generations |
| Pricing | Free vs Premium comparison |

---

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Add your environment variables
Create a `.env.local` file in the root of the project:
```
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
EXPO_PUBLIC_GEMINI_KEY=gen-lang-client-your-key
```

### 3. Run the Supabase migration
In your Supabase project → SQL Editor, run the contents of:
```
supabase/migrations/001_initial_schema.sql
```

### 4. Start the app
```bash
npx expo start
```
Scan the QR code with the **Expo Go** app on your phone.

---

## Building for App Store / Google Play

### Install EAS CLI
```bash
npm install -g eas-cli
eas login
eas build:configure
```

### Build
```bash
# iOS
eas build --platform ios

# Android
eas build --platform android

# Both
eas build --platform all
```

### Submit
```bash
eas submit --platform ios
eas submit --platform android
```

---

## Tech stack

| Package | Purpose | Replaces |
|---|---|---|
| Expo SDK 51 | Native app framework | Vite |
| Expo Router | File-based navigation | React Router |
| TypeScript | Type safety | Plain JavaScript |
| Supabase | Auth + Database + Storage | Base44 |
| Gemini API | AI features | Base44 agents |
| TanStack Query | Data fetching & caching | Base44 entities |
| Moti | Animations | Framer Motion |
| expo-linear-gradient | Gradients | CSS gradients |
| @expo/vector-icons | Icons | Lucide React |
| date-fns | Date formatting | Same |

---

## Adding RevenueCat (when ready)

1. `npm install react-native-purchases`
2. Create products in App Store Connect and Google Play Console
3. Set up RevenueCat dashboard at revenuecat.com
4. Replace the `Alert.alert('Coming Soon')` in `pricing/index.tsx` with RevenueCat purchase calls
5. Update `isPremium` in `auth-context.tsx` to check RevenueCat entitlements
