import { useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import type { Class, Homework, AIHistory, StudyConversation, AIHistoryType, ChatMessage } from '@/types/database';

export function useClasses() {
  const { user } = useAuth(); const qc = useQueryClient();
  const query = useQuery({ queryKey: ['classes', user?.id], queryFn: async () => { const { data, error } = await supabase.from('classes').select('*').eq('user_id', user!.id).order('created_at'); if (error) throw error; return data as Class[]; }, enabled: !!user, initialData: [] as Class[] });
  const create = useMutation({ mutationFn: async (payload: Omit<Class, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => { const { data, error } = await supabase.from('classes').insert({ ...payload, user_id: user!.id }).select().single(); if (error) throw error; return data; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['classes'] }) });
  const update = useMutation({ mutationFn: async ({ id, data }: { id: string; data: Partial<Class> }) => { const { error } = await supabase.from('classes').update(data).eq('id', id); if (error) throw error; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['classes'] }) });
  const remove = useMutation({ mutationFn: async (id: string) => { const { error } = await supabase.from('classes').delete().eq('id', id); if (error) throw error; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['classes'] }) });
  return { ...query, create, update, remove };
}

export function useHomework() {
  const { user } = useAuth(); const qc = useQueryClient();
  const query = useQuery({ queryKey: ['homework', user?.id], queryFn: async () => { const { data, error } = await supabase.from('homework').select('*').eq('user_id', user!.id).order('due_date', { ascending: true, nullsFirst: false }); if (error) throw error; return data as Homework[]; }, enabled: !!user, initialData: [] as Homework[] });
  const create = useMutation({ mutationFn: async (payload: Omit<Homework, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => { const { data, error } = await supabase.from('homework').insert({ ...payload, user_id: user!.id }).select().single(); if (error) throw error; return data; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['homework'] }) });
  const update = useMutation({ mutationFn: async ({ id, data }: { id: string; data: Partial<Homework> }) => { const { error } = await supabase.from('homework').update(data).eq('id', id); if (error) throw error; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['homework'] }) });
  const remove = useMutation({ mutationFn: async (id: string) => { const { error } = await supabase.from('homework').delete().eq('id', id); if (error) throw error; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['homework'] }) });
  return { ...query, create, update, remove };
}

export function useAIHistory(type?: AIHistoryType) {
  const { user } = useAuth(); const qc = useQueryClient();
  const query = useQuery({ queryKey: ['ai_history', user?.id, type], queryFn: async () => { let q = supabase.from('ai_history').select('*').eq('user_id', user!.id).order('created_at', { ascending: false }); if (type) q = q.eq('type', type); const { data, error } = await q; if (error) throw error; return data as AIHistory[]; }, enabled: !!user, initialData: [] as AIHistory[] });
  const save = useMutation({ mutationFn: async (payload: Omit<AIHistory, 'id' | 'user_id' | 'created_at'>) => { const { data, error } = await supabase.from('ai_history').insert({ ...payload, user_id: user!.id }).select().single(); if (error) throw error; return data; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['ai_history'] }) });
  const remove = useMutation({ mutationFn: async (id: string) => { const { error } = await supabase.from('ai_history').delete().eq('id', id); if (error) throw error; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['ai_history'] }) });
  return { ...query, save, remove };
}

export function useStudyConversations() {
  const { user } = useAuth(); const qc = useQueryClient();
  const query = useQuery({ queryKey: ['study_conversations', user?.id], queryFn: async () => { const { data, error } = await supabase.from('study_conversations').select('*').eq('user_id', user!.id).order('updated_at', { ascending: false }); if (error) throw error; return data as StudyConversation[]; }, enabled: !!user, initialData: [] as StudyConversation[] });
  const create = useMutation({ mutationFn: async (title?: string) => { const { data, error } = await supabase.from('study_conversations').insert({ user_id: user!.id, title: title ?? `Study Plan – ${new Date().toLocaleDateString()}`, messages: [] }).select().single(); if (error) throw error; return data as StudyConversation; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['study_conversations'] }) });
  const updateMessages = useMutation({ mutationFn: async ({ id, messages }: { id: string; messages: ChatMessage[] }) => { const { error } = await supabase.from('study_conversations').update({ messages: messages as any }).eq('id', id); if (error) throw error; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['study_conversations'] }) });
  const remove = useMutation({ mutationFn: async (id: string) => { const { error } = await supabase.from('study_conversations').delete().eq('id', id); if (error) throw error; }, onSuccess: () => qc.invalidateQueries({ queryKey: ['study_conversations'] }) });
  return { ...query, create, updateMessages, remove };
}

export function useFileUpload() {
  const { user } = useAuth();
  const upload = useCallback(async (fileUri: string, bucket: 'quiz-images' | 'teacher-files', mimeType = 'image/jpeg'): Promise<string> => {
    const fileName = fileUri.split('/').pop() ?? `upload-${Date.now()}`;
    const path = `${user!.id}/${Date.now()}-${fileName}`;
    const formData = new FormData();
    formData.append('file', { uri: fileUri, name: fileName, type: mimeType } as any);
    const { error } = await supabase.storage.from(bucket).upload(path, formData, { contentType: mimeType });
    if (error) throw error;
    return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl;
  }, [user]);
  return { upload };
}
