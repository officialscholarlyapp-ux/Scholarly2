export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: { Row: { id: string; email: string | null; full_name: string | null; avatar_url: string | null; created_at: string }; Insert: Omit<Database['public']['Tables']['profiles']['Row'], 'created_at'>; Update: Partial<Database['public']['Tables']['profiles']['Insert']> };
      subscriptions: { Row: { id: string; user_id: string; plan: 'free' | 'premium'; status: 'active' | 'inactive' | 'cancelled'; trial_used: boolean; stripe_customer_id: string | null; stripe_subscription_id: string | null; current_period_end: string | null; created_at: string; updated_at: string }; Insert: Omit<Database['public']['Tables']['subscriptions']['Row'], 'id' | 'created_at' | 'updated_at'>; Update: Partial<Database['public']['Tables']['subscriptions']['Insert']> };
      classes: { Row: { id: string; user_id: string; name: string; teacher: string | null; credits: number; current_grade: number | null; is_weighted: boolean; color: string; reminder_days: number[]; reminder_time: string | null; created_at: string; updated_at: string }; Insert: Omit<Database['public']['Tables']['classes']['Row'], 'id' | 'created_at' | 'updated_at'>; Update: Partial<Database['public']['Tables']['classes']['Insert']> };
      homework: { Row: { id: string; user_id: string; title: string; subject: string | null; description: string | null; due_date: string | null; status: 'todo' | 'in_progress' | 'done'; priority: 'low' | 'medium' | 'high'; created_at: string; updated_at: string }; Insert: Omit<Database['public']['Tables']['homework']['Row'], 'id' | 'created_at' | 'updated_at'>; Update: Partial<Database['public']['Tables']['homework']['Insert']> };
      ai_history: { Row: { id: string; user_id: string; type: 'quiz' | 'flashcards' | 'summary' | 'study_guide' | 'teacher_analyzer' | 'get_an_a'; title: string | null; input_summary: string | null; result: Json; created_at: string }; Insert: Omit<Database['public']['Tables']['ai_history']['Row'], 'id' | 'created_at'>; Update: Partial<Database['public']['Tables']['ai_history']['Insert']> };
      study_conversations: { Row: { id: string; user_id: string; title: string; messages: Json; created_at: string; updated_at: string }; Insert: Omit<Database['public']['Tables']['study_conversations']['Row'], 'id' | 'created_at' | 'updated_at'>; Update: Partial<Database['public']['Tables']['study_conversations']['Insert']> };
    };
  };
}

export type Profile = Database['public']['Tables']['profiles']['Row'];
export type Subscription = Database['public']['Tables']['subscriptions']['Row'];
export type Class = Database['public']['Tables']['classes']['Row'];
export type Homework = Database['public']['Tables']['homework']['Row'];
export type AIHistory = Database['public']['Tables']['ai_history']['Row'];
export type StudyConversation = Database['public']['Tables']['study_conversations']['Row'];
export type HomeworkStatus = Homework['status'];
export type HomeworkPriority = Homework['priority'];
export type AIHistoryType = AIHistory['type'];
export interface ChatMessage { role: 'user' | 'assistant'; content: string; timestamp?: string }
