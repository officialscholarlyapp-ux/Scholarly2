import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import type { Profile, Subscription } from '@/types/database';

interface AuthContextValue {
  user: User | null; session: Session | null; profile: Profile | null; subscription: Subscription | null;
  isAuthenticated: boolean; isLoading: boolean; isPremium: boolean;
  signInWithEmail: (email: string, password: string) => Promise<{ error: string | null }>;
  signUpWithEmail: (email: string, password: string, fullName?: string) => Promise<{ error: string | null }>;
  signInWithGoogle: () => Promise<void>;
  signInWithApple: () => Promise<void>;
  signOut: () => Promise<void>;
  refreshSubscription: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadProfile = useCallback(async (uid: string) => {
    const { data } = await supabase.from('profiles').select('*').eq('id', uid).single();
    setProfile(data);
  }, []);

  const loadSubscription = useCallback(async (uid: string) => {
    const { data } = await supabase.from('subscriptions').select('*').eq('user_id', uid).single();
    setSubscription(data);
  }, []);

  const refreshSubscription = useCallback(async () => {
    if (user) await loadSubscription(user.id);
  }, [user, loadSubscription]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session); setUser(session?.user ?? null);
      if (session?.user) {
        Promise.all([loadProfile(session.user.id), loadSubscription(session.user.id)]).finally(() => setIsLoading(false));
      } else { setIsLoading(false); }
    });
    const { data: { subscription: sub } } = supabase.auth.onAuthStateChange((_e, session) => {
      setSession(session); setUser(session?.user ?? null);
      if (session?.user) { loadProfile(session.user.id); loadSubscription(session.user.id); }
      else { setProfile(null); setSubscription(null); }
    });
    return () => sub.unsubscribe();
  }, [loadProfile, loadSubscription]);

  const signInWithEmail = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };
  const signUpWithEmail = async (email: string, password: string, fullName?: string) => {
    const { error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
    return { error: error?.message ?? null };
  };
  const signInWithGoogle = async () => { await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: 'scholarly://auth/callback' } }); };
  const signInWithApple = async () => { await supabase.auth.signInWithOAuth({ provider: 'apple', options: { redirectTo: 'scholarly://auth/callback' } }); };
  const signOut = async () => { await supabase.auth.signOut(); };
  const isPremium = subscription?.plan === 'premium' && subscription?.status === 'active';

  return (
    <AuthContext.Provider value={{ user, session, profile, subscription, isAuthenticated: !!user, isLoading, isPremium, signInWithEmail, signUpWithEmail, signInWithGoogle, signInWithApple, signOut, refreshSubscription }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
