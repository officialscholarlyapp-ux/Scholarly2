import { Dimensions } from 'react-native';
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export const Colors = {
  primary: '#6366f1',
  primaryLight: '#818cf8',
  primaryDark: '#4f46e5',
  secondary: '#a855f7',
  accent: '#10b981',
  warning: '#f59e0b',
  destructive: '#ef4444',
  success: '#22c55e',
  chart1: '#6366f1', chart2: '#a855f7', chart3: '#06b6d4', chart4: '#f59e0b', chart5: '#10b981',
  dark: {
    background: '#0f172a',
    backgroundSecondary: '#1e293b',
    card: '#1e293b',
    cardBorder: '#334155',
    surface: '#293548',
    foreground: '#f1f5f9',
    foregroundMuted: '#94a3b8',
    foregroundSubtle: '#64748b',
    inputBg: '#1e293b',
    inputBorder: '#334155',
  },
  white: '#ffffff',
  black: '#000000',
  transparent: 'transparent',
} as const;

export const Typography = {
  sizes: { xs: 11, sm: 13, base: 15, md: 16, lg: 18, xl: 20, '2xl': 24, '3xl': 28, '4xl': 34 },
  weights: { normal: '400' as const, medium: '500' as const, semibold: '600' as const, bold: '700' as const, extrabold: '800' as const },
} as const;

export const Spacing = { xs: 4, sm: 8, md: 12, base: 16, lg: 20, xl: 24, '2xl': 32, '3xl': 40 } as const;
export const Radius = { sm: 8, md: 12, lg: 16, xl: 20, '2xl': 24, full: 9999 } as const;
export const Shadows = {
  sm: { shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.08, shadowRadius: 3, elevation: 2 },
  md: { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.12, shadowRadius: 8, elevation: 4 },
  lg: { shadowColor: '#6366f1', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.2, shadowRadius: 16, elevation: 8 },
} as const;
export const Layout = { screenWidth: SCREEN_WIDTH, screenHeight: SCREEN_HEIGHT, horizontalPadding: 20, tabBarHeight: 80 } as const;
